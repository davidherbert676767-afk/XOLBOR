package com.xolbor.app

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object OnlineApi {
    private const val PREFS = "xolbor_session"
    private var token: String? = null
    private var currentUser: JSONObject? = null
    private var initialized = false

    fun init(context: Context) {
        if (initialized) return
        val p = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        token = p.getString("token", null)
        val saved = p.getString("user", null)
        currentUser = saved?.let { runCatching { JSONObject(it) }.getOrNull() }
        initialized = true
    }

    private fun save(context: Context, t: String, user: JSONObject) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString("token", t).putString("user", user.toString()).apply()
        token = t
        currentUser = user
    }

    private fun request(method: String, path: String, body: JSONObject? = null): JSONObject = run {
        val base = BuildConfig.XOLBOR_API_URL.trimEnd('/')
        val conn = (URL(base + path).openConnection() as HttpURLConnection)
        conn.requestMethod = method
        conn.connectTimeout = 15000
        conn.readTimeout = 20000
        conn.setRequestProperty("Accept", "application/json")
        token?.let { conn.setRequestProperty("Authorization", "Bearer $it") }
        if (body != null) {
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
        val obj = if (text.isBlank()) JSONObject() else JSONObject(text)
        if (code !in 200..299) throw IllegalStateException(obj.optString("error", "Erro HTTP $code"))
        obj
    }

    suspend fun signup(context: Context, email: String, username: String, password: String): JSONObject = withContext(Dispatchers.IO) {
        val res = request("POST", "/auth/signup", JSONObject().apply { put("email", email); put("username", username); put("password", password) })
        save(context, res.getString("token"), res.getJSONObject("user")); res
    }

    suspend fun login(context: Context, identifier: String, password: String): JSONObject = withContext(Dispatchers.IO) {
        val res = request("POST", "/auth/login", JSONObject().apply { put("identifier", identifier); put("password", password) })
        save(context, res.getString("token"), res.getJSONObject("user")); res
    }

    suspend fun me(): JSONObject = withContext(Dispatchers.IO) { request("GET", "/me").also { currentUser = it.getJSONObject("user") } }
    suspend fun games(): JSONArray = withContext(Dispatchers.IO) { request("GET", "/games").getJSONArray("games") }
    suspend fun createGame(name: String, description: String, icon: String, mapType: String = "Ilha", theme: String = "Éter", maxPlayers: Int = 12, gravity: Float = 1f, timeLimit: Int = 10, objects: String = "Plataformas,Cristais", customItems: String = "[]"): JSONObject = withContext(Dispatchers.IO) {
        request("POST", "/games", JSONObject().apply {
            put("name",name); put("description",description); put("icon",icon); put("map_type",mapType); put("theme",theme); put("max_players",maxPlayers); put("gravity",gravity); put("time_limit",timeLimit); put("objects",objects); put("custom_items",customItems)
        })
    }
    suspend fun sendChat(gameId: String, text: String): JSONObject = withContext(Dispatchers.IO) { request("POST", "/games/$gameId/chat", JSONObject().put("text",text)) }
    suspend fun chat(gameId: String, after: Long = 0): JSONArray = withContext(Dispatchers.IO) { request("GET", "/games/$gameId/chat?after=$after").getJSONArray("messages") }
    suspend fun spendCoins(amount: Int, reason: String): JSONObject = withContext(Dispatchers.IO) { request("POST", "/wallet/spend", JSONObject().put("amount",amount).put("reason",reason)) }
    suspend fun friends(): JSONObject = withContext(Dispatchers.IO) { request("GET", "/friends") }
    suspend fun friendRequest(username: String): JSONObject = withContext(Dispatchers.IO) { request("POST", "/friends/request", JSONObject().put("username",username)) }
    suspend fun acceptFriend(username: String): JSONObject = withContext(Dispatchers.IO) { request("POST", "/friends/accept", JSONObject().put("username",username)) }
    suspend fun adminBan(username: String, reason: String): JSONObject = withContext(Dispatchers.IO) { request("POST", "/admin/ban", JSONObject().put("username",username).put("reason",reason)) }
    suspend fun adminUnban(username: String): JSONObject = withContext(Dispatchers.IO) { request("POST", "/admin/unban", JSONObject().put("username",username)) }
    suspend fun adminRole(username: String, role: String): JSONObject = withContext(Dispatchers.IO) { request("POST", "/admin/role", JSONObject().put("username",username).put("role",role)) }
    suspend fun rooms(gameId: String): JSONArray = withContext(Dispatchers.IO) { request("GET", "/rooms?game=$gameId").getJSONArray("rooms") }
    suspend fun createRoom(gameId: String): JSONObject = withContext(Dispatchers.IO) { request("POST", "/rooms", JSONObject().put("game", gameId)) }
    suspend fun joinRoom(roomId: String): JSONObject = withContext(Dispatchers.IO) { request("POST", "/rooms/$roomId/join") }
    suspend fun adminUsers(): JSONArray = withContext(Dispatchers.IO) { request("GET", "/admin/users").getJSONArray("users") }
    suspend fun items(): JSONArray = withContext(Dispatchers.IO) { request("GET", "/items").getJSONArray("items") }
    suspend fun createItem(name: String, shape: String, color: String, accent: String, size: Float, accessory: String): JSONObject = withContext(Dispatchers.IO) { request("POST", "/items", JSONObject().apply { put("name",name); put("shape",shape); put("color",color); put("accent",accent); put("size",size); put("accessory",accessory) }) }
    suspend fun deleteItem(id: String): JSONObject = withContext(Dispatchers.IO) { request("DELETE", "/items/$id") }

    fun isLoggedIn() = token != null
    fun user() = currentUser
    fun logout(context: Context) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
        token = null; currentUser = null
    }
}
