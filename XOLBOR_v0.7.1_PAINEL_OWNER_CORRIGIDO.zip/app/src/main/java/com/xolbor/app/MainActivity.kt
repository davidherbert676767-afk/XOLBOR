package com.xolbor.app
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import kotlin.math.cos
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.FilterChip

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import org.json.JSONArray
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import android.view.View
import android.view.MotionEvent
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.Typeface
import android.content.Context
import android.content.SharedPreferences
import kotlin.math.sin
import kotlin.math.abs
import android.opengl.Matrix

private val XBlue = Color(0xFF1683FF)
private val XDark = Color(0xFF07111F)
private val XCard = Color(0xFF111C2C)

data class Game(val id: Int, val title: String, val subtitle: String, val rating: Int, val icon: String, val creator: String = "XOLBOR", val serverId: String? = null)

data class CoinPackage(
    val sku: String,
    val coins: Int,
    val title: String,
    val description: String
)

val coinPackages = listOf(
    CoinPackage("xolbor_coins_100", 100, "100 moedas", "Pacote inicial"),
    CoinPackage("xolbor_coins_500", 500, "500 moedas", "Pacote popular"),
    CoinPackage("xolbor_coins_1200", 1200, "1.200 moedas", "Pacote grande"),
    CoinPackage("xolbor_coins_3000", 3000, "3.000 moedas", "Pacote máximo"),
    CoinPackage("xolbor_coins_5000", 5000, "5.000 moedas", "Pacote avançado"),
    CoinPackage("xolbor_coins_10000", 10000, "10.000 moedas", "Pacote premium"),
    CoinPackage("xolbor_coins_25000", 25000, "25.000 moedas", "Pacote especial"),
    CoinPackage("xolbor_coins_50000", 50000, "50.000 moedas", "Pacote gigante"),
    CoinPackage("xolbor_coins_100000", 100000, "100.000 moedas", "Pacote lendário")
)

data class Skin(val name: String, val price: Int, val emoji: String)
data class Friend(val name: String, val status: String, val avatar: String)
data class ChatMessage(val user: String, val text: String, val mine: Boolean = false)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { XolborApp() }
    }
}

@Composable
fun XolborApp() {
    val context = LocalContext.current
    var splash by remember { mutableStateOf(true) }
    var loggedIn by remember { mutableStateOf(false) }
    var restoring by remember { mutableStateOf(true) }
    var tab by remember { mutableIntStateOf(0) }
    var coins by remember { mutableIntStateOf(1250) }
    var selectedGame by remember { mutableStateOf<Game?>(null) }
    var games by remember { mutableStateOf(initialGames()) }

    LaunchedEffect(Unit) {
        OnlineApi.init(context)
        if (OnlineApi.isLoggedIn()) {
            runCatching { OnlineApi.me() }.onSuccess {
                loggedIn = true
                coins = it.getJSONObject("user").optInt("coins", coins)
            }.onFailure { OnlineApi.logout(context) }
        }
        restoring = false
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = XBlue, background = XDark, surface = XCard)) {
        if (splash || restoring) SplashScreen(onDone = { splash = false })
        else if (!loggedIn) LoginScreen(onLoggedIn = { loggedIn = true })
        else if (selectedGame != null) GameScreen(game = selectedGame!!, onBack = { selectedGame = null })
        else MainShell(
            tab = tab, onTab = { tab = it }, coins = coins, onCoins = { coins = it }, games = games,
            onGames = { games = it }, onGame = { selectedGame = it }, onLogout = { OnlineApi.logout(context); loggedIn = false; tab = 0 },
            role = OnlineApi.user()?.optString("role", "PLAYER") ?: "PLAYER"
        )
    }
}

@Composable
fun SplashScreen(onDone: () -> Unit) {
    val scale = remember { Animatable(0.5f) }
    LaunchedEffect(Unit) {
        scale.animateTo(1f, tween(700))
        kotlinx.coroutines.delay(900)
        onDone()
    }
    Box(
        Modifier.fillMaxSize().background(XDark),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                painter = painterResource(id = com.xolbor.app.R.drawable.xolbor_logo),
                contentDescription = "Logo XOLBOR",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(260.dp)
                    .graphicsLayer(scaleX = scale.value, scaleY = scale.value)
            )
            Text("Jogue. Crie. Personalize.", color = Color.LightGray, fontSize = 16.sp)
        }
    }
}

@Composable
fun LoginScreen(onLoggedIn: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf("login") }
    var method by remember { mutableStateOf("email") }
    var step by remember { mutableIntStateOf(1) }
    var email by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var confirmPass by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    fun finishSignup() {
        error = when {
            !email.contains("@") -> "Digite um e-mail válido."
            username.length < 3 -> "O nome de usuário precisa ter pelo menos 3 caracteres."
            pass.length < 8 -> "A senha precisa ter pelo menos 8 caracteres."
            pass != confirmPass -> "As senhas não são iguais."
            else -> ""
        }
        if (error.isEmpty()) {
            busy = true
            scope.launch {
                try { OnlineApi.signup(context, email, username, pass); onLoggedIn() }
                catch (e: Exception) { error = e.message ?: "Não foi possível criar a conta." }
                finally { busy = false }
            }
        }
    }

    Box(Modifier.fillMaxSize().background(XDark), contentAlignment = Alignment.Center) {
        Card(
            colors = CardDefaults.cardColors(containerColor = XCard),
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier.padding(22.dp).fillMaxWidth()
        ) {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Image(
                    painter = painterResource(id = com.xolbor.app.R.drawable.xolbor_logo),
                    contentDescription = "Logo XOLBOR",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.size(150.dp).align(Alignment.CenterHorizontally)
                )
                Text(
                    if (mode == "login") "Entrar" else "Criar conta",
                    fontSize = 25.sp,
                    fontWeight = FontWeight.Bold
                )

                if (mode == "login") {
                    OutlinedTextField(
                        email, { email = it; error = "" },
                        label = { Text("Usuário ou e-mail") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        pass, { pass = it; error = "" },
                        label = { Text("Senha") },
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            if (email.isBlank() || pass.isBlank()) { error = "Preencha usuário/e-mail e senha." }
                            else {
                                busy = true; error = ""
                                scope.launch {
                                    try { OnlineApi.login(context, email, pass); onLoggedIn() }
                                    catch (e: Exception) { error = e.message ?: "Falha ao entrar." }
                                    finally { busy = false }
                                }
                            }
                        },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (busy) "ENTRANDO…" else "ENTRAR") }

                    OutlinedButton(onClick = { error = "Login Google ainda precisa ser ligado ao Google Identity/Firebase. O login por e-mail já usa o backend XOLBOR." }, modifier = Modifier.fillMaxWidth()) {
                        Text("Continuar com Google")
                    }
                    Text(
                        "Não tem conta? Criar conta",
                        color = XBlue,
                        modifier = Modifier.clickable {
                            mode = "signup"
                            method = "email"
                            step = 1
                            error = ""
                        }
                    )
                } else {
                    if (step == 1) {
                        Text("1. Escolha como criar sua conta", color = Color.LightGray, fontSize = 14.sp)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = method == "email",
                                onClick = { method = "email"; error = "" },
                                label = { Text("📧 E-mail") },
                                modifier = Modifier.weight(1f)
                            )
                            FilterChip(
                                selected = method == "google",
                                onClick = { method = "google"; error = "" },
                                label = { Text("G Google") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (method == "email") {
                            OutlinedTextField(
                                email, { email = it; error = "" },
                                label = { Text("Seu e-mail") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Button(
                                onClick = {
                                    if (email.contains("@") && email.contains(".")) { step = 2; error = "" }
                                    else error = "Digite um e-mail válido."
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("CONTINUAR") }
                        } else {
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF17263D))) {
                                Column(Modifier.padding(14.dp)) {
                                    Text("Conta Google", fontWeight = FontWeight.Bold)
                                    Text("Na versão final, este botão abrirá o login seguro do Google. O XOLBOR não recebe sua senha do Google.", color = Color.LightGray, fontSize = 12.sp)
                                }
                            }
                            Button(
                                onClick = { step = 2; error = "" },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("CONTINUAR COM GOOGLE") }
                        }
                    } else {
                        Text("2. Crie seu perfil XOLBOR", color = Color.LightGray, fontSize = 14.sp)
                        if (method == "google") {
                            Text("Google conectado (protótipo)", color = XBlue, fontSize = 13.sp)
                        }
                        OutlinedTextField(
                            username, { username = it; error = "" },
                            label = { Text("Nome de usuário") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            pass, { pass = it; error = "" },
                            label = { Text("Senha XOLBOR") },
                            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            confirmPass, { confirmPass = it; error = "" },
                            label = { Text("Confirmar senha") },
                            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Button(onClick = { finishSignup() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                            Text(if (busy) "CRIANDO…" else "CRIAR CONTA")
                        }
                        Text(
                            "← Voltar",
                            color = XBlue,
                            modifier = Modifier.clickable { step = 1; error = "" }
                        )
                    }

                    Text(
                        "Já tenho uma conta",
                        color = XBlue,
                        modifier = Modifier.clickable { mode = "login"; step = 1; error = "" }
                    )
                }

                if (error.isNotBlank()) Text(error, color = Color(0xFFFF8A80), fontSize = 13.sp)
                Text(
                    "Online: contas por e-mail já usam o backend XOLBOR com senha protegida por hash e sessão JWT. O Google será conectado na próxima etapa.",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }
        }
    }
}

fun initialGames(): List<Game> = listOf(
    Game(1, "Torre Insana", "Suba a torre, supere obstáculos e chegue ao topo", 99, "🗼", "XOLBOR", "tower"),
    Game(2, "Desastres Naturais", "Sobreviva a desastres em mapas 3D", 99, "🌪️", "XOLBOR", "disasters"),
    Game(3, "Ilhas do Éter", "Explore ilhas, poderes e aventuras originais", 99, "🌊", "XOLBOR", "ether"),
    Game(4, "Neon Rush", "Corridas futuristas multiplayer", 99, "🏎️", "XOLBOR", "neon")
)

@Composable
fun MainShell(
    tab: Int, onTab: (Int) -> Unit, coins: Int, onCoins: (Int) -> Unit, games: List<Game>,
    onGames: (List<Game>) -> Unit, onGame: (Game) -> Unit, onLogout: () -> Unit, role: String
) {
    val isStaff = role == "OWNER" || role == "ADMIN"
    val labels = if (isStaff) listOf("Início","Jogos","Avatar","Amigos","Servidores","Loja","Perfil","Dono")
                 else listOf("Início","Jogos","Avatar","Amigos","Servidores","Loja","Perfil")
    Scaffold(containerColor = XDark, bottomBar = {
        NavigationBar(containerColor = Color(0xFF061A35)) {
            labels.forEachIndexed { i, label ->
                NavigationBarItem(selected = tab == i, onClick = { onTab(i) }, icon = {
                    Icon(when(i) {
                        0 -> Icons.Default.Home; 1 -> Icons.Default.SportsEsports; 2 -> Icons.Default.Person;
                        3 -> Icons.Default.Group; 4 -> Icons.Default.Cloud; 5 -> Icons.Default.ShoppingCart;
                        6 -> Icons.Default.AccountCircle; else -> Icons.Default.Security
                    }, contentDescription = label)
                }, label = { Text(label) })
            }
        }
    }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(com.xolbor.app.R.drawable.xolbor_logo),
                    contentDescription = "Logo XOLBOR",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.size(58.dp)
                )
                Surface(shape = RoundedCornerShape(20.dp), color = Color(0xFF17263D)) {
                    Row(Modifier.padding(horizontal=14.dp,vertical=8.dp), verticalAlignment=Alignment.CenterVertically) { XolborCoinIcon(26.dp); Spacer(Modifier.width(6.dp)); Text("$coins", fontWeight=FontWeight.Bold) }
                }
            }
            when(tab) {
                0 -> HomeTab(games,onGame); 1 -> GamesTab(games,onGame,onGames); 2 -> AvatarTab(coins,onCoins);
                3 -> FriendsTab(); 4 -> ServersTab(); 5 -> StoreTab(coins); 6 -> ProfileTab(coins,onLogout);
                7 -> if (isStaff) AdminTab() else HomeTab(games,onGame)
            }
        }
    }
}

@Composable
fun XolborCoinIcon(size: androidx.compose.ui.unit.Dp) {
    Box(Modifier.size(size).background(Color(0xFF8C6CFF), RoundedCornerShape(size/2)).padding(2.dp), contentAlignment=Alignment.Center) {
        Box(Modifier.fillMaxSize().background(Color(0xFF182E62), RoundedCornerShape(size/2)), contentAlignment=Alignment.Center) {
            Text("X", color=Color(0xFFE4D7FF), fontWeight=FontWeight.Black, fontSize=(size.value*0.48f).sp)
        }
    }
}

@Composable
fun HomeTab(games: List<Game>, onGame: (Game) -> Unit) {
    var friends by remember { mutableStateOf<List<Friend>>(emptyList()) }
    LaunchedEffect(Unit) {
        runCatching { OnlineApi.friends() }.onSuccess { response ->
            val f = response.optJSONArray("friends") ?: JSONArray()
            friends = (0 until f.length()).map { i ->
                val o = f.getJSONObject(i)
                Friend(o.optString("username"), "Amigo", "🧑")
            }
        }
    }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Recomendados", fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(games.take(3)) { game ->
                    Card(
                        modifier = Modifier.width(230.dp).clickable { onGame(game) },
                        colors = CardDefaults.cardColors(containerColor = XCard),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Box(Modifier.fillMaxWidth().height(100.dp).background(Color(0xFF173B65), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                                Text(game.icon, fontSize = 48.sp)
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(game.title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text(game.subtitle, color = Color.LightGray, maxLines = 1)
                        }
                    }
                }
            }
        }
        item {
            Text("Seus amigos", fontSize = 21.sp, fontWeight = FontWeight.Bold)
            androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(friends.take(4)) { friend ->
                    Card(colors = CardDefaults.cardColors(containerColor = XCard), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.width(115.dp).padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(friend.avatar, fontSize = 34.sp)
                            Text(friend.name, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text(friend.status, fontSize = 11.sp, color = if (friend.status == "Offline") Color.Gray else Color(0xFF70E58A), maxLines = 1)
                        }
                    }
                }
            }
        }
        item { Text("Todos os jogos", fontSize = 21.sp, fontWeight = FontWeight.Bold) }
        items(games) { game -> GameCard(game, onGame) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0E2A45))) {
                Column(Modifier.padding(18.dp)) {
                    Text("🎥 Programa de YouTubers", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Text("Criadores com até 10.000 inscritos podem solicitar verificação. Após confirmação e vídeo sobre um jogo XOLBOR, a recompensa é de 500 moedas.")
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = {}) { Text("Solicitar verificação") }
                }
            }
        }
    }
}

@Composable
fun GamesTab(games: List<Game>, onGame: (Game) -> Unit, onGames: (List<Game>) -> Unit) {
    val scope = rememberCoroutineScope()
    var creating by remember { mutableStateOf(false) }
    if (creating) {
        CreateGameScreen(
            onCancel = { creating = false },
            onCreate = { title, description, icon ->
                creating = false
                scope.launch {
                    try {
                        val obj = OnlineApi.createGame(title, description, icon).getJSONObject("game")
                        val id = obj.optString("id").hashCode()
                        onGames(games + Game(id, title, description, 100, icon, obj.optString("owner_username", "Você")))
                    } catch (_: Exception) {
                        val nextId = (games.maxOfOrNull { it.id } ?: 0) + 1
                        onGames(games + Game(nextId, title, description, 100, icon, "Você (offline)"))
                    }
                }
            }
        )
        return
    }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Todos os jogos", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("${games.size} jogos disponíveis", color = Color.LightGray)
                }
                Button(onClick = { creating = true }) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("Criar jogo")
                }
            }
        }
        items(games) { GameCard(it, onGame) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF102B45))) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("🎮 Crie seu próprio jogo", fontWeight = FontWeight.Bold, fontSize = 19.sp)
                    Text("Escolha nome, descrição e ícone. No modo online, seus jogos poderão ser publicados para outros jogadores.", color = Color.LightGray)
                    Text("Protótipo: a publicação e os mundos 3D reais precisam de servidor/backend.", color = Color.Gray, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun CreateGameScreen(onCancel: () -> Unit, onCreate: (String, String, String) -> Unit) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var icon by remember { mutableStateOf("🎮") }
    var error by remember { mutableStateOf("") }
    val icons = listOf("🎮", "🏝️", "🚀", "⚔️", "🏎️", "🐾", "🌋", "🧟", "🏰", "⭐")
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onCancel) { Icon(Icons.Default.ArrowBack, contentDescription = "Voltar") }
            Text("Criar jogo", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        }
        Card(colors = CardDefaults.cardColors(containerColor = XCard), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Novo jogo", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(title, { title = it.take(30); error = "" }, label = { Text("Nome do jogo") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(description, { description = it.take(80); error = "" }, label = { Text("Descrição") }, modifier = Modifier.fillMaxWidth())
                Text("Escolha o ícone", color = Color.LightGray)
                androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(icons) { item ->
                        FilterChip(selected = icon == item, onClick = { icon = item }, label = { Text(item, fontSize = 22.sp) })
                    }
                }
                Button(onClick = {
                    when {
                        title.trim().length < 3 -> error = "O nome precisa ter pelo menos 3 caracteres."
                        description.trim().length < 5 -> error = "Escreva uma descrição curta."
                        else -> onCreate(title.trim(), description.trim(), icon)
                    }
                }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Publish, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("CRIAR E PUBLICAR")
                }
                if (error.isNotBlank()) Text(error, color = Color(0xFFFF8A80), fontSize = 13.sp)
            }
        }
        Text("Na versão online, haverá editor de mapas, objetos, scripts seguros, testes e publicação/moderação.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun GameCard(game: Game, onGame: (Game) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onGame(game) },
        colors = CardDefaults.cardColors(containerColor = XCard),
        shape = RoundedCornerShape(22.dp)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(82.dp).background(Color(0xFF153A66), RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center
            ) { Text(game.icon, fontSize = 42.sp) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(game.title, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text(game.subtitle, color = Color.LightGray)
                Text("👍 Avaliação ${game.rating}%", color = Color.LightGray)
                Text("Criado por ${game.creator}", color = Color.Gray, fontSize = 12.sp)
            }
            Icon(Icons.Default.PlayArrow, contentDescription = "Jogar", tint = XBlue)
        }
    }
}

@Composable
fun AvatarTab(coins: Int, onCoins: (Int) -> Unit) {
    var gender by remember { mutableStateOf("menino") }
    val skins = listOf(
        Skin("Padrão menino", 0, "🧑"),
        Skin("Padrão menina", 0, "👩"),
        Skin("Neon", 350, "🕶️"),
        Skin("Galaxy", 600, "🌌"),
        Skin("Fogo", 800, "🔥")
    )
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Seu Avatar 3D", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        XolborAvatar3DPreview("Azul", "Moderno", "Coroa", Modifier.fillMaxWidth())
        Text("Personalizar", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = gender == "menino", onClick = { gender = "menino" }, label = { Text("Menino 🧑") })
            FilterChip(selected = gender == "menina", onClick = { gender = "menina" }, label = { Text("Menina 👩") })
        }
        Spacer(Modifier.height(14.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(skins) { skin ->
                Card(colors = CardDefaults.cardColors(containerColor = XCard)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(skin.emoji, fontSize = 35.sp)
                        Spacer(Modifier.width(12.dp))
                        Text(skin.name, Modifier.weight(1f), fontWeight = FontWeight.Bold)
                        if (skin.price == 0) Text("Grátis")
                        else Button(onClick = { if (coins >= skin.price) onCoins(coins - skin.price) }) {
                            Text("🪙 ${skin.price}")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FriendsTab() {
    val scope = rememberCoroutineScope()
    var search by remember { mutableStateOf("") }
    var friends by remember { mutableStateOf(listOf<Friend>()) }
    var incoming by remember { mutableStateOf(listOf<String>()) }
    var message by remember { mutableStateOf("") }
    suspend fun refresh() {
        val r = OnlineApi.friends();
        val f = r.getJSONArray("friends"); val inc = r.getJSONArray("incoming")
        friends = (0 until f.length()).map { val o=f.getJSONObject(it); Friend(o.optString("username"),"Amigo","🧑") }
        incoming = (0 until inc.length()).map { inc.getJSONObject(it).optString("username") }
    }
    LaunchedEffect(Unit) { runCatching { refresh() } }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Text("Amizades", fontSize=25.sp, fontWeight=FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
            OutlinedTextField(search,{search=it},label={Text("Nome do jogador")},modifier=Modifier.weight(1f))
            Spacer(Modifier.width(8.dp)); Button(onClick={ scope.launch { runCatching { OnlineApi.friendRequest(search); message="Solicitação enviada!"; refresh() }.onFailure { message=it.message ?: "Erro" } } }) { Text("Adicionar") }
        }
        if (message.isNotBlank()) Text(message,color=Color(0xFF7CFF9A))
        if (incoming.isNotEmpty()) {
            Text("Solicitações",fontSize=19.sp,fontWeight=FontWeight.Bold)
            incoming.forEach { name -> Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){ Text(name,Modifier.weight(1f),fontWeight=FontWeight.Bold); Button(onClick={scope.launch{runCatching{OnlineApi.acceptFriend(name);refresh()}.onFailure{message=it.message?:"Erro"}}}){Text("Aceitar")} } }
        }
        Text("Seus amigos",fontSize=19.sp,fontWeight=FontWeight.Bold)
        if (friends.isEmpty()) Text("Você ainda não tem amigos. Adicione jogadores pelo nome.",color=Color.LightGray)
        friends.forEach { f -> Card(colors=CardDefaults.cardColors(containerColor=XCard),shape=RoundedCornerShape(18.dp)){ Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically){ Text(f.avatar,fontSize=34.sp); Spacer(Modifier.width(12.dp)); Column{Text(f.name,fontWeight=FontWeight.Bold);Text(f.status,color=Color.LightGray,fontSize=13.sp)} } } }
    }
}

@Composable
fun StoreTab(coins: Int) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Loja de moedas", fontSize = 28.sp, fontWeight = FontWeight.Black)
            Text(
                "Escolha um pacote de moedas XOLBOR. O preço final será definido no sistema de cobrança da loja.",
                color = Color.LightGray,
                fontSize = 14.sp
            )
            Spacer(Modifier.height(8.dp))
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = Color(0xFF17263D),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("Saldo atual", color = Color.LightGray)
                    Text("🪙 $coins moedas", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        items(coinPackages) { pack ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101F36)),
                shape = RoundedCornerShape(20.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("🪙 ${pack.coins}", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text(pack.title, fontWeight = FontWeight.SemiBold)
                        Text(pack.description, color = Color.LightGray, fontSize = 13.sp)
                        Text("ID: ${pack.sku}", color = Color.Gray, fontSize = 11.sp)
                    }
                    OutlinedButton(onClick = {
                        // O botão fica pronto para ser ligado ao Google Play Billing / Galaxy Store IAP.
                    }) {
                        Text("Comprar")
                    }
                }
            }
        }
        item {
            Text(
                "Pagamento: esta tela não guarda dados bancários. A integração de cobrança deve usar o sistema oficial da loja e credenciais configuradas no console do desenvolvedor.",
                color = Color.Gray,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
fun ProfileTab(coins: Int, onLogout: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Meu perfil", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = XCard), shape = RoundedCornerShape(24.dp)) {
            Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(88.dp).background(Color(0xFF173B65), RoundedCornerShape(44.dp)), contentAlignment = Alignment.Center) { Text("🧑", fontSize = 48.sp) }
                Spacer(Modifier.width(16.dp))
                Column { Text(OnlineApi.user()?.optString("username", "XOLBOR") ?: "XOLBOR", fontSize = 23.sp, fontWeight = FontWeight.Black); Text("@" + (OnlineApi.user()?.optString("email", "") ?: ""), color = Color.LightGray); Row(verticalAlignment=Alignment.CenterVertically){XolborCoinIcon(22.dp);Spacer(Modifier.width(5.dp));Text("$coins moedas", color = XBlue)} }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = XCard)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Estatísticas", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("🎮 Jogos jogados: 24")
                Text("🏆 Vitórias: 11")
                Text("👥 Amigos: 5")
                Text("🎨 Itens de avatar: sincronizados")
                Button(onClick = onLogout) { Text("SAIR DA CONTA") }
            }
        }
        Text("Sessão salva com segurança no aparelho; a senha não é armazenada.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun ServersTab() {
    val scope = rememberCoroutineScope()
    var rooms by remember { mutableStateOf(org.json.JSONArray()) }
    var selectedGame by remember { mutableStateOf("tower") }
    var message by remember { mutableStateOf("") }

    fun refresh() {
        scope.launch { runCatching { OnlineApi.rooms(selectedGame) }.onSuccess { rooms = it }.onFailure { message = it.message ?: "Erro ao carregar servidores." } }
    }
    LaunchedEffect(selectedGame) { refresh() }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Servidores por jogo", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Cada jogo possui suas próprias salas. Só jogadores reais aparecem.", color = Color.LightGray, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("tower" to "Torre", "disasters" to "Desastres", "ether" to "Éter", "neon" to "Neon").forEach { (id,label) ->
                FilterChip(selected = selectedGame == id, onClick = { selectedGame = id }, label = { Text(label) })
            }
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = { scope.launch { runCatching { OnlineApi.createRoom(selectedGame) }.onSuccess { message = "Sala criada. Entrando..."; refresh() }.onFailure { message = it.message ?: "Erro." } } }) {
            Text("CRIAR/ENTRAR EM UMA SALA")
        }
        if (message.isNotBlank()) Text(message, color = Color(0xFF7CFF9A), fontSize = 13.sp, modifier = Modifier.padding(vertical = 8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(rooms.length()) { i ->
                val r = rooms.getJSONObject(i)
                Card(colors = CardDefaults.cardColors(containerColor = XCard), shape = RoundedCornerShape(18.dp)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Servidor #${r.optString("roomId").takeLast(6)}", fontWeight = FontWeight.Bold)
                            Text("${r.optInt("players", 0)}/${r.optInt("maxPlayers", 12)} jogadores reais", color = Color.LightGray)
                        }
                        Button(onClick = { scope.launch { runCatching { OnlineApi.joinRoom(r.optString("roomId")) }.onSuccess { message = "Você entrou na sala."; refresh() }.onFailure { message = it.message ?: "Erro ao entrar." } } }) { Text("ENTRAR") }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminTab() {
    val scope=rememberCoroutineScope(); var target by remember{mutableStateOf("")}; var message by remember{mutableStateOf("")}; var users by remember{mutableStateOf(listOf<String>())}
    suspend fun refresh(){ val a=OnlineApi.adminUsers(); users=(0 until a.length()).map{val o=a.getJSONObject(it); "${o.optString("username")} • ${o.optString("role")}"} }
    LaunchedEffect(Unit){runCatching{refresh()}}
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{Text("👑 Painel do Dono",fontSize=27.sp,fontWeight=FontWeight.Black);Text("Cargo: ${OnlineApi.user()?.optString("role","PLAYER")}",color=XBlue);Text("Dono protegido contra ban e rebaixamento.",color=Color.LightGray)}
        item{OutlinedTextField(target,{target=it},label={Text("Nome do usuário")},modifier=Modifier.fillMaxWidth())}
        item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={scope.launch{runCatching{OnlineApi.adminBan(target,"Banido pelo dono");message="$target banido.";refresh()}.onFailure{message=it.message?:"Erro"}}}){Text("Banir")};OutlinedButton(onClick={scope.launch{runCatching{OnlineApi.adminUnban(target);message="$target desbanido.";refresh()}.onFailure{message=it.message?:"Erro"}}}){Text("Desbanir")}}}
        item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={scope.launch{runCatching{OnlineApi.adminRole(target,"ADMIN");message="$target agora é ADMIN.";refresh()}.onFailure{message=it.message?:"Erro"}}}){Text("Dar ADMIN")};OutlinedButton(onClick={scope.launch{runCatching{OnlineApi.adminRole(target,"PLAYER");message="$target rebaixado.";refresh()}.onFailure{message=it.message?:"Erro"}}}){Text("Remover ADMIN")}}}
        if(message.isNotBlank())item{Text(message,color=Color(0xFF7CFF9A))}
        item{Text("Jogadores",fontSize=20.sp,fontWeight=FontWeight.Bold)}
        items(users){u->Text(u,color=Color.LightGray)}
    }
}

@Composable
fun GameScreen(game: Game, onBack: () -> Unit) {
    var showChat by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(10.dp),verticalAlignment=Alignment.CenterVertically){
                IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,"Voltar",tint=Color.White)}
                Column(Modifier.weight(1f)){Text(game.title,color=Color.White,fontSize=19.sp,fontWeight=FontWeight.Bold);Text("Mundo 3D • avatar XOLBOR • controles de toque",color=Color.LightGray,fontSize=12.sp)}
                IconButton(onClick={showChat=!showChat}){Icon(Icons.Default.Chat,"Chat",tint=Color.White)}
            }
            Box(Modifier.weight(1f)){
                Xolbor3DGameView(game.id,Modifier.fillMaxSize())
                Mobile3DControls(Modifier.fillMaxSize())
            }
        }
        if(showChat) GameChatPanel(gameId=game.serverId ?: game.id.toString(),messages=remember{mutableStateListOf()},onClose={showChat=false})
    }
}

@Composable
fun Mobile3DControls(modifier: Modifier=Modifier){
    // The 3D renderer receives touch gestures directly; this overlay gives a familiar mobile control hint.
    Box(modifier){Text("Arraste para olhar • toque/arraste para mover • toque duas vezes para pular",color=Color.White.copy(alpha=.75f),fontSize=11.sp,modifier=Modifier.align(Alignment.BottomCenter).padding(bottom=8.dp))}
}

@Composable
fun GameChatPanel(
    gameId: String,
    messages: MutableList<ChatMessage>,
    onClose: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var draft by remember { mutableStateOf("") }
    var muted by remember { mutableStateOf(setOf<String>()) }
    var notice by remember { mutableStateOf("") }
    var lastMessageId by remember { mutableLongStateOf(0L) }

    LaunchedEffect(gameId) {
        while (true) {
            try {
                val arr = OnlineApi.chat(gameId, lastMessageId)
                for (i in 0 until arr.length()) {
                    val item = arr.getJSONObject(i)
                    val id = item.optLong("id")
                    if (id > lastMessageId) lastMessageId = id
                    val name = item.optString("username", "Jogador")
                    if (name != (OnlineApi.user()?.optString("username") ?: "")) messages.add(ChatMessage(name, item.optString("text"), false))
                }
            } catch (_: Exception) { }
            kotlinx.coroutines.delay(2500)
        }
    }

    val blockedWords = listOf(
        "idiota", "burro", "otario", "otário", "palhaco", "palhaço", "merda", "porra",
        "caralho", "viado", "fdp", "filho da puta"
    )

    fun filterMessage(text: String): String {
        var result = text.trim()
        blockedWords.forEach { word ->
            val regex = Regex("(?i)" + Regex.escape(word))
            result = regex.replace(result, "***")
        }
        return result
    }

    fun sendMessage() {
        val clean = filterMessage(draft)
        if (clean.isBlank()) return
        draft = ""
        scope.launch {
            try {
                OnlineApi.sendChat(gameId, clean)
                messages.add(ChatMessage(OnlineApi.user()?.optString("username", "Você") ?: "Você", clean, true))
                notice = "Mensagem enviada para o servidor"
            } catch (e: Exception) {
                messages.add(ChatMessage("Você", clean, true))
                notice = "Modo offline: ${e.message ?: "servidor indisponível"}"
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        Card(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 62.dp, end = 10.dp)
            .widthIn(min = 280.dp, max = 360.dp)
            .heightIn(min = 360.dp, max = 520.dp),
        colors = CardDefaults.cardColors(containerColor = XCard),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("💬 Chat do jogo", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Fale com quem está na sala", color = Color.LightGray, fontSize = 11.sp)
                }
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Fechar chat")
                }
            }

            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                items(messages.filter { it.user !in muted }) { msg ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.mine) Arrangement.End else Arrangement.Start) {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (msg.mine) Color(0xFF164E82) else Color(0xFF18263A)
                            ),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Column(Modifier.padding(horizontal = 10.dp, vertical = 7.dp)) {
                                Text(msg.user, fontSize = 11.sp, color = Color.LightGray, fontWeight = FontWeight.Bold)
                                Text(msg.text, fontSize = 14.sp)
                                if (!msg.mine) {
                                    TextButton(
                                        onClick = {
                                            muted = muted + msg.user
                                            notice = "${msg.user} foi silenciado nesta sala."
                                        },
                                        contentPadding = PaddingValues(0.dp)
                                    ) { Text("Silenciar", fontSize = 10.sp) }
                                }
                            }
                        }
                    }
                }
            }

            if (notice.isNotBlank()) {
                Text(notice, color = Color(0xFF8FD3FF), fontSize = 11.sp, modifier = Modifier.padding(bottom = 4.dp))
            }

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
                OutlinedTextField(
                    value = draft,
                    onValueChange = { draft = it.take(120) },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Digite uma mensagem…") },
                    maxLines = 3
                )
                Spacer(Modifier.width(6.dp))
                IconButton(onClick = { sendMessage() }) {
                    Icon(Icons.Default.Send, contentDescription = "Enviar")
                }
            }
            Text(
                "Filtro automático • denunciar e moderar no servidor na versão online",
                color = Color.Gray,
                fontSize = 10.sp,
                modifier = Modifier.padding(top = 5.dp)
            )
        }
        }
    }
}

@Composable
fun PlayableGameView(mode: Int, modifier: Modifier = Modifier, onReady: (XolborGameView) -> Unit = {}) {
    val context = LocalContext.current
    AndroidView(
        factory = { XolborGameView(context, mode).also(onReady) },
        modifier = modifier
    )
}

@Composable
fun MobileGameControls(gameView: XolborGameView?) {
    var running by remember { mutableStateOf(false) }
    var joyX by remember { mutableFloatStateOf(0f) }
    var joyY by remember { mutableFloatStateOf(0f) }

    Box(Modifier.fillMaxSize().padding(16.dp)) {
        Box(
            Modifier.align(Alignment.BottomStart)
                .size(150.dp)
                .background(Color(0x663A4A60), RoundedCornerShape(75.dp))
                .pointerInput(gameView) {
                    detectDragGestures(
                        onDragEnd = { joyX = 0f; joyY = 0f; gameView?.setMoveInput(0f, 0f, running) },
                        onDragCancel = { joyX = 0f; joyY = 0f; gameView?.setMoveInput(0f, 0f, running) },
                        onDrag = { change, drag ->
                            change.consume()
                            joyX = (joyX + drag.x / 75f).coerceIn(-1f, 1f)
                            joyY = (joyY + drag.y / 75f).coerceIn(-1f, 1f)
                            gameView?.setMoveInput(joyX, joyY, running)
                        }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.size(58.dp).offset((joyX * 38f).dp, (joyY * 38f).dp)
                .background(Color(0xDD1683FF), RoundedCornerShape(29.dp)))
            Text("ANDAR", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }

        Row(Modifier.align(Alignment.BottomEnd).padding(bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = { running = !running; gameView?.setRunning(running); gameView?.setMoveInput(joyX, joyY, running) },
                colors = ButtonDefaults.buttonColors(containerColor = if (running) Color(0xFF19A55B) else Color(0xCC26384D))
            ) { Text(if (running) "🏃 Correndo" else "🏃 Correr") }
            Button(
                onClick = { gameView?.jump() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xCC7A42D6))
            ) { Text("🦘 Pular") }
        }
    }
}

/**
 * Mini-games jogáveis que rodam diretamente dentro do APK.
 * São leves e não dependem de servidor para funcionar no protótipo.
 */
class XolborGameView(context: Context, private val mode: Int) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD }
    private var playerX = 0.5f
    private var playerY = 0.78f
    private var velocityY = 0f
    private var score = 0
    private var lives = 3
    private var gameOver = false
    private var lastTime = System.nanoTime()
    private var elapsed = 0f
    private var spawnTimer = 0f
    private var obstacleX = 0.65f
    private var obstacleY = 0.15f
    private var obstacleLane = 1
    private var targetLane = 1
    private var collected = 0
    private var touchDownX = 0f
    private var touchDownY = 0f
    private var inputX = 0f
    private var inputY = 0f
    private var running = false
    private val speed: Float get() = if (running) 0.75f else 0.38f
    private var jumpRequested = false
    private var jumpTimer = 0f

    init {
        isFocusable = true
        setBackgroundColor(AndroidColor.BLACK)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = System.nanoTime()
        var dt = (now - lastTime) / 1_000_000_000f
        lastTime = now
        dt = dt.coerceIn(0f, 0.05f)
        if (!gameOver) update(dt)
        drawScene(canvas)
        if (!gameOver) postInvalidateDelayed(16) else invalidate()
    }

    private fun update(dt: Float) {
        elapsed += dt
        if (jumpTimer > 0f) jumpTimer -= dt
        if (jumpRequested) { jumpTimer = 0.55f }
        when (mode) {
            1 -> updateCubeLift(dt)
            2 -> updatePhoenix(dt)
            3 -> updateNeonDrive(dt)
            else -> updateSkyRails(dt)
        }
    }

    private fun updateCubeLift(dt: Float) {
        playerX = (playerX + inputX * speed * dt).coerceIn(0.12f, 0.88f)
        if (jumpRequested && playerY >= 0.75f) { velocityY = -1.05f; jumpRequested = false }
        velocityY += 1.8f * dt
        playerY += velocityY * dt
        if (playerY > 0.78f) {
            playerY = 0.78f
            velocityY = 0f
        }
        obstacleY += 0.42f * dt
        if (obstacleY > 0.9f) {
            obstacleY = 0.08f
            obstacleX = 0.25f + Math.random().toFloat() * 0.5f
            score += 10
        }
        if (abs(playerX - obstacleX) < 0.10f && abs(playerY - obstacleY) < 0.10f) {
            lives--
            obstacleY = 0.08f
            obstacleX = 0.25f + Math.random().toFloat() * 0.5f
            if (lives <= 0) gameOver = true
        }
    }

    private fun updatePhoenix(dt: Float) {
        playerX = (playerX + inputX * speed * dt).coerceIn(0.08f, 0.92f)
        spawnTimer += dt
        obstacleY += 0.30f * dt
        if (obstacleY > 0.9f) {
            obstacleY = 0.08f
            obstacleX = 0.12f + Math.random().toFloat() * 0.76f
        }
        if (abs(playerX - obstacleX) < 0.09f && abs(playerY - obstacleY) < 0.09f) {
            collected++
            score += 25
            obstacleY = 0.08f
            obstacleX = 0.12f + Math.random().toFloat() * 0.76f
        }
        playerY = 0.55f + sin(elapsed * 2.2f) * 0.16f - if (jumpTimer > 0f) 0.16f else 0f
    }

    private fun updateNeonDrive(dt: Float) {
        if (abs(inputX) > 0.35f) targetLane = (targetLane + if (inputX > 0) 1 else -1).coerceIn(0, 2)
        playerX += (targetLane * 0.5f + 0.5f - playerX) * minOf(1f, dt * 8f)
        obstacleY += 0.55f * dt
        if (obstacleY > 1.05f) {
            obstacleY = 0.08f
            obstacleLane = (0..2).random()
            score += 15
        }
        val obstaclePos = 0.25f + obstacleLane * 0.25f
        if (obstacleY > 0.72f && obstacleY < 0.88f && abs(playerX - obstaclePos) < 0.09f) {
            lives--
            obstacleY = 0.08f
            obstacleLane = (0..2).random()
            if (lives <= 0) gameOver = true
        }
    }

    private fun updateSkyRails(dt: Float) {
        if (abs(inputX) > 0.35f) targetLane = if (inputX < 0) 0 else 1
        playerX += (targetLane * 0.5f + 0.25f - playerX) * minOf(1f, dt * 7f)
        obstacleY += 0.38f * dt
        if (obstacleY > 1.0f) {
            obstacleY = 0.05f
            obstacleLane = (0..1).random()
            score += 12
        }
        val obstaclePos = if (obstacleLane == 0) 0.33f else 0.67f
        if (obstacleY > 0.68f && obstacleY < 0.86f && abs(playerX - obstaclePos) < 0.12f) {
            lives--
            obstacleY = 0.05f
            if (lives <= 0) gameOver = true
        }
    }

    private fun drawScene(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        paint.style = Paint.Style.FILL
        paint.color = AndroidColor.rgb(5, 12, 25)
        canvas.drawRect(0f, 0f, w, h, paint)

        when (mode) {
            1 -> drawCubeLift(canvas, w, h)
            2 -> drawPhoenix(canvas, w, h)
            3 -> drawNeonDrive(canvas, w, h)
            else -> drawSkyRails(canvas, w, h)
        }

        textPaint.color = AndroidColor.WHITE
        textPaint.textSize = 18f
        canvas.drawText("Pontos: $score", 18f, 30f, textPaint)
        canvas.drawText("❤ $lives", w - 90f, 30f, textPaint)

        if (gameOver) {
            paint.color = AndroidColor.argb(220, 0, 0, 0)
            canvas.drawRect(0f, 0f, w, h, paint)
            textPaint.textSize = 34f
            textPaint.color = AndroidColor.WHITE
            textPaint.textAlign = Paint.Align.CENTER
            canvas.drawText("FIM DE JOGO", w / 2f, h / 2f - 20f, textPaint)
            textPaint.textSize = 18f
            canvas.drawText("Toque para jogar novamente", w / 2f, h / 2f + 25f, textPaint)
            textPaint.textAlign = Paint.Align.LEFT
        }
    }

    private fun drawCubeLift(canvas: Canvas, w: Float, h: Float) {
        drawGrid(canvas, w, h)
        drawCube(canvas, playerX * w, playerY * h, 46f, AndroidColor.CYAN)
        drawCube(canvas, obstacleX * w, obstacleY * h, 42f, AndroidColor.MAGENTA)
        drawButton(canvas, w, h, "TOQUE / PULE")
    }

    private fun drawPhoenix(canvas: Canvas, w: Float, h: Float) {
        drawStars(canvas, w, h)
        val x = playerX * w
        val y = playerY * h
        paint.color = AndroidColor.rgb(255, 90, 20)
        canvas.drawCircle(x, y, 32f, paint)
        paint.color = AndroidColor.YELLOW
        canvas.drawCircle(x + 20f, y - 8f, 14f, paint)
        paint.color = AndroidColor.RED
        canvas.drawOval(x - 55f, y - 5f, x - 5f, y + 24f, paint)
        canvas.drawOval(x + 5f, y - 5f, x + 55f, y + 24f, paint)
        paint.color = AndroidColor.CYAN
        canvas.drawCircle(obstacleX * w, obstacleY * h, 14f, paint)
        textPaint.color = AndroidColor.WHITE
        textPaint.textSize = 16f
        canvas.drawText("Cristais: $collected", 18f, h - 70f, textPaint)
        drawButton(canvas, w, h, "MOVA PARA PEGAR")
    }

    private fun drawNeonDrive(canvas: Canvas, w: Float, h: Float) {
        paint.color = AndroidColor.rgb(20, 20, 35)
        canvas.drawRect(0f, 0f, w, h, paint)
        for (i in 0..12) {
            val y = h * 0.35f + i * h * 0.055f
            paint.color = AndroidColor.rgb(30, 80, 120)
            canvas.drawLine(w * 0.18f, y, w * 0.82f, y, paint)
        }
        for (lane in 0..2) {
            val x = w * (0.25f + lane * 0.25f)
            paint.color = AndroidColor.rgb(70, 40, 120)
            canvas.drawLine(x, h * 0.25f, x, h * 0.9f, paint)
        }
        drawCar(canvas, playerX * w, h * 0.82f, 50f, AndroidColor.CYAN)
        drawCar(canvas, (0.25f + obstacleLane * 0.25f) * w, obstacleY * h, 44f, AndroidColor.MAGENTA)
        textPaint.color = AndroidColor.LTGRAY
        textPaint.textSize = 16f
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("←  Toque à esquerda/direita  →", w / 2f, h - 28f, textPaint)
        textPaint.textAlign = Paint.Align.LEFT
    }

    private fun drawSkyRails(canvas: Canvas, w: Float, h: Float) {
        drawStars(canvas, w, h)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 8f
        paint.color = AndroidColor.CYAN
        canvas.drawLine(w * 0.33f, h * 0.2f, w * 0.33f, h, paint)
        paint.color = AndroidColor.MAGENTA
        canvas.drawLine(w * 0.67f, h * 0.2f, w * 0.67f, h, paint)
        paint.style = Paint.Style.FILL
        drawCube(canvas, playerX * w, h * 0.78f, 48f, AndroidColor.WHITE)
        val ox = if (obstacleLane == 0) 0.33f else 0.67f
        drawCube(canvas, ox * w, obstacleY * h, 40f, AndroidColor.YELLOW)
        textPaint.color = AndroidColor.WHITE
        textPaint.textSize = 16f
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("Toque no lado do trilho para trocar", w / 2f, h - 28f, textPaint)
        textPaint.textAlign = Paint.Align.LEFT
    }

    private fun drawGrid(canvas: Canvas, w: Float, h: Float) {
        paint.color = AndroidColor.rgb(15, 40, 65)
        for (i in 0..10) canvas.drawLine(0f, h * i / 10f, w, h * i / 10f, paint)
        for (i in 0..10) canvas.drawLine(w * i / 10f, 0f, w * i / 10f, h, paint)
    }

    private fun drawStars(canvas: Canvas, w: Float, h: Float) {
        paint.color = AndroidColor.WHITE
        for (i in 0..30) {
            val x = ((i * 73) % 100) / 100f * w
            val y = ((i * 47) % 85) / 100f * h
            canvas.drawCircle(x, y, if (i % 3 == 0) 3f else 1.5f, paint)
        }
    }

    private fun drawCube(canvas: Canvas, cx: Float, cy: Float, size: Float, color: Int) {
        paint.color = color
        paint.style = Paint.Style.FILL
        canvas.drawRect(cx - size / 2, cy - size / 2, cx + size / 2, cy + size / 2, paint)
        paint.color = AndroidColor.argb(120, 255, 255, 255)
        canvas.drawRect(cx - size / 2, cy - size / 2, cx, cy, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        paint.color = AndroidColor.WHITE
        canvas.drawRect(cx - size / 2, cy - size / 2, cx + size / 2, cy + size / 2, paint)
        paint.style = Paint.Style.FILL
    }

    private fun drawCar(canvas: Canvas, cx: Float, cy: Float, size: Float, color: Int) {
        paint.color = color
        canvas.drawRoundRect(cx - size / 2, cy - size / 2, cx + size / 2, cy + size / 2, 12f, 12f, paint)
        paint.color = AndroidColor.DKGRAY
        canvas.drawRect(cx - size * .28f, cy - size * .30f, cx + size * .28f, cy, paint)
    }

    private fun drawButton(canvas: Canvas, w: Float, h: Float, label: String) {
        paint.color = AndroidColor.argb(150, 20, 40, 70)
        canvas.drawRoundRect(18f, h - 58f, w - 18f, h - 10f, 18f, 18f, paint)
        textPaint.color = AndroidColor.WHITE
        textPaint.textSize = 15f
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(label, w / 2f, h - 29f, textPaint)
        textPaint.textAlign = Paint.Align.LEFT
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touchDownX = event.x
                touchDownY = event.y
                if (gameOver) resetGame()
                return true
            }
            MotionEvent.ACTION_UP -> {
                val dx = event.x - touchDownX
                val w = width.toFloat()
                when (mode) {
                    1 -> if (abs(dx) > 35f) playerX = (playerX + if (dx > 0) 0.10f else -0.10f).coerceIn(0.12f, 0.88f) else if (playerY >= 0.75f) velocityY = -1.05f
                    2 -> playerX = (event.x / w).coerceIn(0.08f, 0.92f)
                    3 -> targetLane = if (event.x < w / 2f) maxOf(0, targetLane - 1) else minOf(2, targetLane + 1)
                    else -> targetLane = if (event.x < w / 2f) 0 else 1
                }
                invalidate()
                return true
            }
        }
        return true
    }

    fun setMoveInput(x: Float, y: Float, sprint: Boolean) {
        inputX = x.coerceIn(-1f, 1f)
        inputY = y.coerceIn(-1f, 1f)
        running = sprint
    }

    fun setRunning(value: Boolean) { running = value }

    fun jump() { if (!gameOver) jumpRequested = true }

    private fun resetGame() {
        playerX = 0.5f
        playerY = 0.78f
        velocityY = 0f
        score = 0
        lives = 3
        gameOver = false
        elapsed = 0f
        obstacleY = 0.08f
        obstacleX = 0.65f
        obstacleLane = 1
        targetLane = 1
        collected = 0
        lastTime = System.nanoTime()
        postInvalidateDelayed(16)
    }
}

/* XOLBOR_SKIN_CREATOR */
@Composable
fun XolborSkinCreator(
    coins: Int,
    onCoinsChange: (Int) -> Unit
) {
    var skinName by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("Azul") }
    var hair by remember { mutableStateOf("Clássico") }
    var accessory by remember { mutableStateOf("Nenhum") }
    var created by remember { mutableStateOf(false) }

    val skins = listOf(
        "Neon", "Galaxy", "Fire", "Ice", "Shadow", "Cyber", "Lava",
        "Ocean", "Forest", "Sunset", "Royal", "Crystal", "Robot", "Ninja"
    )

    Column(
        modifier = Modifier.fillMaxWidth().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("🎨 Criador de Skin", style = MaterialTheme.typography.titleLarge)
        Text(
            "Crie seu próprio visual e use a skin no seu avatar.",
            style = MaterialTheme.typography.bodyMedium
        )

        OutlinedTextField(
            value = skinName,
            onValueChange = { skinName = it.take(20) },
            label = { Text("Nome da skin") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Text("Skins prontas", style = MaterialTheme.typography.titleMedium)
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.heightIn(max = 280.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(skins) { name ->
                Button(onClick = {
                    skinName = name
                    created = true
                }) {
                    Text(name)
                }
            }
        }

        Text("Cor do corpo")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Azul", "Vermelho", "Verde", "Roxo", "Amarelo").forEach {
                FilterChip(
                    selected = body == it,
                    onClick = { body = it },
                    label = { Text(it) }
                )
            }
        }

        Text("Cabelo")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Clássico", "Moicano", "Cacheado", "Cyber").forEach {
                FilterChip(
                    selected = hair == it,
                    onClick = { hair = it },
                    label = { Text(it) }
                )
            }
        }

        Text("Acessório")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Nenhum", "Óculos", "Boné", "Coroa", "Fone").forEach {
                FilterChip(
                    selected = accessory == it,
                    onClick = { accessory = it },
                    label = { Text(it) }
                )
            }
        }

        Button(
            onClick = {
                if (skinName.isNotBlank()) created = true
            },
            enabled = skinName.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Salvar e usar minha skin")
        }

        if (created) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("✅ Skin equipada", style = MaterialTheme.typography.titleMedium)
                    Text("$skinName • $body • $hair • $accessory")
                }
            }
        }
    }
}

/* XOLBOR_3D_AVATAR_EVOLUTION */

/**
 * Preview 3D simples do avatar XOLBOR.
 * O mesmo visual (bodyColor/hair/accessory) é usado para montar a renderização.
 * A câmera pode ser girada por toque.
 */
@Composable
fun XolborAvatar3DPreview(
    bodyColor: String,
    hair: String,
    accessory: String,
    modifier: Modifier = Modifier
) {
    AndroidView(
        modifier = modifier
            .fillMaxWidth()
            .height(300.dp),
        factory = { context ->
            val avatarRenderer = XolborAvatarRenderer(bodyColor, hair, accessory)
            val view = GLSurfaceView(context).apply {
                setEGLContextClientVersion(2)
                setRenderer(avatarRenderer)
                renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
            }
            var downX = 0f
            view.setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.x
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.x - downX
                        (v as GLSurfaceView).queueEvent {
                            avatarRenderer.rotateBy(dx * 0.5f)
                        }
                        downX = e.x
                        true
                    }
                    else -> true
                }
            }
            view
        }
    )
}

class XolborAvatarRenderer(
    private val bodyColorName: String,
    private val hairName: String,
    private val accessoryName: String
) : GLSurfaceView.Renderer {

    private var angle = 0f
    private var program = 0
    private var positionHandle = 0
    private var colorHandle = 0
    private var mvpHandle = 0
    private val projection = FloatArray(16)
    private val view = FloatArray(16)
    private val model = FloatArray(16)
    private val mvp = FloatArray(16)
    private val temp = FloatArray(16)

    private val vertexShader = """
        attribute vec4 aPosition;
        uniform mat4 uMvp;
        void main() { gl_Position = uMvp * aPosition; }
    """.trimIndent()

    private val fragmentShader = """
        precision mediump float;
        uniform vec4 uColor;
        void main() { gl_FragColor = uColor; }
    """.trimIndent()

    override fun onSurfaceCreated(gl: javax.microedition.khronos.opengles.GL10?, config: javax.microedition.khronos.egl.EGLConfig?) {
        GLES20.glClearColor(0.08f, 0.09f, 0.12f, 1f)
        program = buildProgram(vertexShader, fragmentShader)
        positionHandle = GLES20.glGetAttribLocation(program, "aPosition")
        colorHandle = GLES20.glGetUniformLocation(program, "uColor")
        mvpHandle = GLES20.glGetUniformLocation(program, "uMvp")
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
    }

    override fun onSurfaceChanged(gl: javax.microedition.khronos.opengles.GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        val aspect = if (height == 0) 1f else width.toFloat() / height.toFloat()
        val near = 1f
        val far = 20f
        val top = kotlin.math.tan(Math.toRadians(42.0)).toFloat() * near
        val right = top * aspect
        Matrix.frustumM(projection, 0, -right, right, -top, top, near, far)
        Matrix.setLookAtM(view, 0, 0f, 0.25f, 5.2f, 0f, 0.15f, 0f, 0f, 1f, 0f)
    }

    override fun onDrawFrame(gl: javax.microedition.khronos.opengles.GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        // Build a real MVP matrix so the avatar is visible instead of being clipped.
        // A full 3D engine can replace this renderer later; this renderer provides
        // a lightweight Android-native 3D avatar preview without external assets.
        drawCube(0f, 0f, 0f, 0.72f, 0.95f, color(bodyColorName))
        drawCube(0f, 1.05f, 0f, 0.48f, 0.48f, floatArrayOf(0.95f, 0.72f, 0.50f, 1f))
        drawCube(-0.62f, 0.02f, 0f, 0.22f, 0.75f, color(bodyColorName))
        drawCube(0.62f, 0.02f, 0f, 0.22f, 0.75f, color(bodyColorName))
        drawCube(-0.22f, -0.95f, 0f, 0.23f, 0.75f, floatArrayOf(0.12f,0.12f,0.14f,1f))
        drawCube(0.22f, -0.95f, 0f, 0.23f, 0.75f, floatArrayOf(0.12f,0.12f,0.14f,1f))
        if (hairName != "Clássico") {
            drawCube(0f, 1.42f, 0f, 0.52f, 0.16f, floatArrayOf(0.12f,0.06f,0.03f,1f))
        }
        if (accessoryName != "Nenhum") {
            drawCube(0f, 1.58f, 0f, 0.55f, 0.08f, floatArrayOf(0.95f,0.75f,0.15f,1f))
        }
        angle += 0.35f
    }

    fun rotateBy(delta: Float) { angle += delta }

    private fun drawCube(x: Float, y: Float, z: Float, sx: Float, sy: Float, c: FloatArray) {
        val verts = floatArrayOf(
            -1f,-1f,-1f, 1f,-1f,-1f, 1f,1f,-1f, -1f,1f,-1f,
            -1f,-1f,1f, 1f,-1f,1f, 1f,1f,1f, -1f,1f,1f
        )
        val idx = shortArrayOf(
            0,1,2, 2,3,0, 4,5,6, 6,7,4,
            0,4,7, 7,3,0, 1,5,6, 6,2,1,
            3,2,6, 6,7,3, 0,1,5, 5,4,0
        )
        val fb = java.nio.ByteBuffer.allocateDirect(verts.size*4).order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer()
        fb.put(verts).position(0)
        val ib = java.nio.ByteBuffer.allocateDirect(idx.size*2).order(java.nio.ByteOrder.nativeOrder()).asShortBuffer()
        ib.put(idx).position(0)

        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, x, y, z)
        Matrix.rotateM(model, 0, angle, 0f, 1f, 0f)
        Matrix.scaleM(model, 0, sx, sy, sx)
        Matrix.multiplyMM(temp, 0, view, 0, model, 0)
        Matrix.multiplyMM(mvp, 0, projection, 0, temp, 0)

        GLES20.glUseProgram(program)
        GLES20.glUniformMatrix4fv(mvpHandle, 1, false, mvp, 0)
        GLES20.glEnableVertexAttribArray(positionHandle)
        GLES20.glVertexAttribPointer(positionHandle,3,GLES20.GL_FLOAT,false,0,fb)
        GLES20.glUniform4fv(colorHandle,1,c,0)
        GLES20.glDrawElements(GLES20.GL_TRIANGLES,idx.size,GLES20.GL_UNSIGNED_SHORT,ib)
        GLES20.glDisableVertexAttribArray(positionHandle)
    }

    private fun color(n: String) = when(n) {
        "Vermelho" -> floatArrayOf(0.85f,0.15f,0.15f,1f)
        "Verde" -> floatArrayOf(0.15f,0.75f,0.25f,1f)
        "Roxo" -> floatArrayOf(0.55f,0.25f,0.85f,1f)
        "Amarelo" -> floatArrayOf(0.95f,0.75f,0.12f,1f)
        else -> floatArrayOf(0.18f,0.45f,0.85f,1f)
    }

    private fun buildProgram(v: String, f: String): Int {
        fun shader(type: Int, src: String): Int {
            val id = GLES20.glCreateShader(type)
            GLES20.glShaderSource(id, src)
            GLES20.glCompileShader(id)
            return id
        }
        val vs = shader(GLES20.GL_VERTEX_SHADER, v)
        val fs = shader(GLES20.GL_FRAGMENT_SHADER, f)
        val id = GLES20.glCreateProgram()
        GLES20.glAttachShader(id, vs); GLES20.glAttachShader(id, fs)
        GLES20.glLinkProgram(id)
        return id
    }
}


@Composable
fun Xolbor3DGameView(gameId: Int, modifier: Modifier=Modifier){
    AndroidView(modifier=modifier,factory={context->
        val renderer=XolborWorldRenderer(gameId)
        GLSurfaceView(context).apply{
            setEGLContextClientVersion(2)
            setRenderer(renderer)
            renderMode=GLSurfaceView.RENDERMODE_CONTINUOUSLY
            var downX=0f; var downY=0f; var lastTap=0L
            setOnTouchListener { _, e ->
                when(e.actionMasked){
                    MotionEvent.ACTION_DOWN -> { downX=e.x; downY=e.y; val now=System.currentTimeMillis(); if(now-lastTap<280) renderer.jump(); lastTap=now; true }
                    MotionEvent.ACTION_MOVE -> { val dx=e.x-downX; val dy=e.y-downY; renderer.look(dx*0.006f); renderer.move(-dy*0.012f, -dx*0.012f); downX=e.x; downY=e.y; true }
                    else -> true
                }
            }
        }
    })
}

class XolborWorldRenderer(private val gameId:Int): GLSurfaceView.Renderer{
    private var program=0; private var posHandle=0; private var colorHandle=0; private var mvpHandle=0
    private val projection=FloatArray(16); private val view=FloatArray(16); private val model=FloatArray(16); private val mvp=FloatArray(16); private val temp=FloatArray(16)
    private var px=0f; private var pz=2.5f; private var py=0f; private var vy=0f; private var yaw=0f
    private var inputForward=0f; private var inputSide=0f; private var elapsed=0f
    private var last=System.nanoTime()
    private val cubeVerts=floatArrayOf(-1f,-1f,-1f,1f,-1f,-1f,1f,1f,-1f,-1f,1f,-1f,-1f,-1f,1f,1f,-1f,1f,1f,1f,1f,-1f,1f,1f)
    private val cubeIdx=shortArrayOf(0,1,2,2,3,0,4,5,6,6,7,4,0,4,7,7,3,0,1,5,6,6,2,1,3,2,6,6,7,3,0,1,5,5,4,0)
    private val vbo:java.nio.FloatBuffer=java.nio.ByteBuffer.allocateDirect(cubeVerts.size*4).order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer().apply{put(cubeVerts);position(0)}
    private val ibo:java.nio.ShortBuffer=java.nio.ByteBuffer.allocateDirect(cubeIdx.size*2).order(java.nio.ByteOrder.nativeOrder()).asShortBuffer().apply{put(cubeIdx);position(0)}
    private val vs="attribute vec4 aPosition; uniform mat4 uMvp; void main(){gl_Position=uMvp*aPosition;}"
    private val fs="precision mediump float; uniform vec4 uColor; void main(){gl_FragColor=uColor;}"

    override fun onSurfaceCreated(gl:javax.microedition.khronos.opengles.GL10?, config:javax.microedition.khronos.egl.EGLConfig?){
        GLES20.glClearColor(.015f,.025f,.06f,1f); GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        program=make(vs,fs); posHandle=GLES20.glGetAttribLocation(program,"aPosition"); colorHandle=GLES20.glGetUniformLocation(program,"uColor"); mvpHandle=GLES20.glGetUniformLocation(program,"uMvp")
    }

    override fun onSurfaceChanged(gl:javax.microedition.khronos.opengles.GL10?,w:Int,h:Int){
        GLES20.glViewport(0,0,w,h); val aspect=(w.toFloat()/h.coerceAtLeast(1)).coerceAtLeast(.5f); Matrix.frustumM(projection,0,-aspect*.72f,aspect*.72f,-.72f,.72f,1f,80f)
    }

    override fun onDrawFrame(gl:javax.microedition.khronos.opengles.GL10?){
        val now=System.nanoTime(); val dt=((now-last)/1e9f).coerceIn(0f,.05f); last=now; elapsed+=dt
        val f=inputForward; val side=inputSide
        px += (kotlin.math.sin(yaw)*f + kotlin.math.cos(yaw)*side)*3.0f*dt
        pz += (kotlin.math.cos(yaw)*f - kotlin.math.sin(yaw)*side)*3.0f*dt
        inputForward=0f; inputSide=0f
        py=(py+vy*dt).coerceAtLeast(0f); if(py==0f&&vy<0f)vy=0f; if(py>0f)vy-=5.5f*dt

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        val camY=2.4f+py
        Matrix.setLookAtM(view,0,px+6.2f*kotlin.math.sin(yaw),camY+2.0f,pz+6.2f*kotlin.math.cos(yaw),px,1.15f+py,pz,0f,1f,0f)

        when(gameId){
            1 -> drawTower()
            2 -> drawDisasters()
            3 -> drawEther()
            4 -> drawNeon()
            else -> drawEther()
        }
        drawPlayer()
    }

    private fun drawTower(){
        cube(px,-.25f,pz,10f,.18f,10f, c(.025f,.055f,.12f))
        for(level in 0..7){
            val y=level*2.25f
            val rot=if(level%2==0) 0f else .55f
            platform(0f,y,-1.5f,4.6f, .16f, rot, if(level%2==0)c(.05f,.55f,.9f) else c(.7f,.15f,.95f))
            cube(-4.5f,y+1.2f,0f,.12f,1.2f,4.8f,c(.04f,.16f,.3f))
            cube(4.5f,y+1.2f,0f,.12f,1.2f,4.8f,c(.04f,.16f,.3f))
            for(i in 0..2){
                val ox=-3f+i*3f+kotlin.math.sin(elapsed*1.4f+level)*.8f
                cube(ox,y+.55f,-.2f,.45f,.12f,.45f,if((i+level)%2==0)c(.95f,.15f,.7f) else c(.05f,.75f,1f))
            }
        }
        for(i in 0..10){
            val a=i*.57f+elapsed*.35f; cube(kotlin.math.sin(a)*7f,1.2f+kotlin.math.cos(a*.7f)*.5f,kotlin.math.cos(a)*7f,.08f,.08f,.08f,c(.3f,.7f,1f))
        }
    }

    private fun drawDisasters(){
        cube(px,-.25f,pz,12f,.18f,12f,c(.03f,.08f,.13f))
        // city blocks
        for(i in 0..7){
            val x=(i%4-1.5f)*3.0f; val z=(i/4-0.5f)*4.2f
            val h=1.2f+(i%3)*.65f
            cube(x,h,z,.9f,h,.9f,if(i%2==0)c(.08f,.22f,.34f) else c(.12f,.16f,.27f))
            for(w in -1..1) cube(x+w*.42f,h*.9f,z-.94f,.12f,.16f,.05f,c(.9f,.65f,.12f))
        }
        // storm / falling debris
        for(i in 0..13){
            val a=i*.8f+elapsed*.9f; val x=kotlin.math.sin(a)*7f; val z=kotlin.math.cos(a*.8f)*6f
            cube(x,3.2f+kotlin.math.sin(elapsed*2f+i)*1.4f,z,.12f,.38f,.12f,c(.2f,.7f,.9f))
        }
        // rising flood
        val water=.08f+kotlin.math.abs(kotlin.math.sin(elapsed*.65f))*.18f
        cube(0f,.03f,0f,9f,water,9f,c(.02f,.35f,.7f,.82f))
    }

    private fun drawEther(){
        cube(px,-.45f,pz,10f,.12f,10f,c(.025f,.035f,.09f))
        val islands=listOf(floatArrayOf(-4f,.5f,-3f),floatArrayOf(4f,1.0f,-1f),floatArrayOf(-2f,1.6f,4f),floatArrayOf(4.5f,2.3f,4f))
        islands.forEachIndexed{idx,v->
            cube(v[0],v[1],v[2],1.8f,.35f,1.5f,c(.08f,.12f,.24f)); cube(v[0],v[1]+.45f,v[2],1.35f,.25f,1.1f,if(idx%2==0)c(.1f,.65f,.95f) else c(.65f,.18f,.95f))
            cube(v[0],v[1]+1.15f,v[2],.28f,.8f,.28f,c(.85f,.2f,1f))
        }
        // bridges
        for(i in 0..3) cube(-.1f,.9f+i*.1f,.3f+i*.9f, .28f,.12f,2.0f,c(.15f,.3f,.55f))
        for(i in 0..11){val a=i*.52f;cube(kotlin.math.sin(a+elapsed*.15f)*7f,1.8f+kotlin.math.sin(a)*.5f,kotlin.math.cos(a)*7f,.07f,.07f,.07f,c(.25f,.75f,1f))}
    }

    private fun drawNeon(){
        cube(px,-.35f,pz,12f,.15f,12f,c(.025f,.025f,.05f))
        // three-lane futuristic track
        for(lane in -1..1){
            cube(lane*1.65f,-.05f,pz, .62f,.06f,12f,c(.06f,.08f,.14f))
            for(i in 0..11){
                val z=-10f+i*2f
                cube(lane*1.65f,.08f,z,.04f,.05f,.55f,if(lane==0)c(.2f,.8f,1f) else c(.8f,.15f,.9f))
            }
        }
        for(i in 0..5){
            val z=-8f+i*4f
            cube(-4.8f,1.2f,z,.1f,1.2f,.1f,c(.1f,.7f,1f)); cube(4.8f,1.2f,z,.1f,1.2f,.1f,c(.9f,.1f,.8f)); cube(0f,2.35f,z,4.8f,.08f,.08f,c(.2f,.8f,1f))
        }
        val gateZ=-6f+((elapsed*4f)%12f)
        cube(-3.8f,.9f,gateZ,.12f,.9f,.12f,c(.8f,.1f,.9f)); cube(3.8f,.9f,gateZ,.12f,.9f,.12f,c(.1f,.8f,1f))
    }

    private fun drawPlayer(){
        // Shared XOLBOR block avatar: body, head, hair, arms and legs.
        cube(px,.62f+py,pz,.48f,.62f,.34f,c(.08f,.5f,1f))
        cube(px,1.62f+py,pz,.37f,.37f,.37f,c(.96f,.76f,.58f))
        cube(px,2.02f+py,pz,.39f,.11f,.39f,c(.5f,.08f,.85f))
        cube(px-.62f,.65f+py,pz,.14f,.48f,.14f,c(.08f,.5f,1f)); cube(px+.62f,.65f+py,pz,.14f,.48f,.14f,c(.08f,.5f,1f))
        cube(px-.22f,.0f+py,pz,.18f,.52f,.18f,c(.08f,.1f,.18f)); cube(px+.22f,.0f+py,pz,.18f,.52f,.18f,c(.08f,.1f,.18f))
    }

    private fun platform(x:Float,y:Float,z:Float,sx:Float,sy:Float,rot:Float,col:FloatArray){
        Matrix.setIdentityM(model,0); Matrix.translateM(model,0,x,y,z); Matrix.rotateM(model,0,rot,0f,1f,0f); Matrix.scaleM(model,0,sx,sy,1.2f); drawModel(col)
    }
    private fun c(r:Float,g:Float,b:Float,a:Float=1f)=floatArrayOf(r,g,b,a)
    private fun drawModel(col:FloatArray){ Matrix.multiplyMM(temp,0,view,0,model,0); Matrix.multiplyMM(mvp,0,projection,0,temp,0); GLES20.glUseProgram(program); GLES20.glUniformMatrix4fv(mvpHandle,1,false,mvp,0); GLES20.glUniform4fv(colorHandle,1,col,0); GLES20.glEnableVertexAttribArray(posHandle); GLES20.glVertexAttribPointer(posHandle,3,GLES20.GL_FLOAT,false,0,vbo); GLES20.glDrawElements(GLES20.GL_TRIANGLES,cubeIdx.size,GLES20.GL_UNSIGNED_SHORT,ibo); GLES20.glDisableVertexAttribArray(posHandle) }
    private fun cube(x:Float,y:Float,z:Float,sx:Float,sy:Float,sz:Float,c:FloatArray){Matrix.setIdentityM(model,0);Matrix.translateM(model,0,x,y,z);Matrix.scaleM(model,0,sx,sy,sz);drawModel(c)}
    fun look(delta:Float){ yaw += delta }
    fun move(forward:Float,side:Float){ inputForward=(inputForward+forward).coerceIn(-1f,1f); inputSide=(inputSide+side).coerceIn(-1f,1f) }
    fun jump(){ if(py<=.001f) vy=2.8f }
    private fun make(v:String,f:String):Int{fun sh(t:Int,s:String):Int{val id=GLES20.glCreateShader(t);GLES20.glShaderSource(id,s);GLES20.glCompileShader(id);return id};val a=sh(GLES20.GL_VERTEX_SHADER,v);val b=sh(GLES20.GL_FRAGMENT_SHADER,f);return GLES20.glCreateProgram().also{GLES20.glAttachShader(it,a);GLES20.glAttachShader(it,b);GLES20.glLinkProgram(it)}}
}

/* XOLBOR_CUBE_LIFT_COMPLETE */
@Composable
fun CubeLift3DGame(onExit: () -> Unit) {
    var score by remember { mutableStateOf(0) }
    var finished by remember { mutableStateOf(false) }
    var rendererRef by remember { mutableStateOf<CubeLiftRenderer?>(null) }
    var running by remember { mutableStateOf(false) }
    var joystickX by remember { mutableFloatStateOf(0f) }
    var joystickY by remember { mutableFloatStateOf(0f) }

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                GLSurfaceView(context).apply {
                    setEGLContextClientVersion(2)
                    val renderer = CubeLiftRenderer(
                        onScore = { score = it },
                        onFinished = { finished = true }
                    )
                    rendererRef = renderer
                    setRenderer(renderer)
                    renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
                    setOnTouchListener { _, _ -> true }
                }
            }
        )

        Box(
            Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("CUBE LIFT 3D", color = Color.White, fontSize = 20.sp)
                Text("🧱 $score / 10", color = Color.White, fontSize = 20.sp)
            }

            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .size(150.dp)
                    .background(Color(0x553A4A60), RoundedCornerShape(75.dp))
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragEnd = {
                                joystickX = 0f
                                joystickY = 0f
                                rendererRef?.setMoveInput(0f, 0f, running)
                            },
                            onDragCancel = {
                                joystickX = 0f
                                joystickY = 0f
                                rendererRef?.setMoveInput(0f, 0f, running)
                            },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                joystickX = (joystickX + dragAmount.x / 75f).coerceIn(-1f, 1f)
                                joystickY = (joystickY + dragAmount.y / 75f).coerceIn(-1f, 1f)
                                rendererRef?.setMoveInput(joystickX, joystickY, running)
                            }
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                Box(
                    Modifier
                        .size(58.dp)
                        .offset(
                            x = (joystickX * 38f).dp,
                            y = (joystickY * 38f).dp
                        )
                        .background(Color(0xCC1683FF), RoundedCornerShape(29.dp))
                )
                Text("MOVE", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Row(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        running = !running
                        rendererRef?.setRunning(running)
                        rendererRef?.setMoveInput(joystickX, joystickY, running)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (running) Color(0xFF19A55B) else Color(0xCC26384D)
                    )
                ) {
                    Text(if (running) "🏃 Correndo" else "🏃 Correr")
                }

                Button(
                    onClick = { rendererRef?.jump() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xCC7A42D6))
                ) {
                    Text("🦘 Pular")
                }
            }

            if (finished) {
                Card(
                    Modifier
                        .align(Alignment.Center)
                        .padding(16.dp)
                ) {
                    Column(
                        Modifier.padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("🏆 Você completou o Cube Lift 3D!")
                        Text("Pontuação: $score")
                        Button(onClick = onExit) { Text("Voltar para XOLBOR") }
                    }
                }
            }

            Button(
                onClick = onExit,
                modifier = Modifier.align(Alignment.BottomCenter)
            ) {
                Text("Sair do jogo")
            }
        }
    }
}

class CubeLiftRenderer(
    val onScore: (Int) -> Unit,
    val onFinished: () -> Unit
) : GLSurfaceView.Renderer {
    private var program = 0
    private var pos = 0
    private var color = 0
    @Volatile private var px = 0f
    @Volatile private var pz = 0f
    @Volatile private var py = 0f
    @Volatile private var inputX = 0f
    @Volatile private var inputY = 0f
    @Volatile private var running = false
    @Volatile private var jumpRequested = false
    private var jumpVelocity = 0f
    private var score = 0
    private var done = false

    private val cubes = mutableListOf(
        floatArrayOf(-2.2f,-1.5f), floatArrayOf(1.8f,-1.1f),
        floatArrayOf(-1.1f,.8f), floatArrayOf(2.1f,1.4f),
        floatArrayOf(0f,2f), floatArrayOf(-2.3f,2f),
        floatArrayOf(2.5f,0f), floatArrayOf(-.4f,-2.3f),
        floatArrayOf(1f,2.6f), floatArrayOf(-2.7f,-.1f)
    )
    private val vs = "attribute vec4 aPosition; void main(){gl_Position=aPosition;}"
    private val fs = "precision mediump float; uniform vec4 uColor; void main(){gl_FragColor=uColor;}"

    override fun onSurfaceCreated(gl: javax.microedition.khronos.opengles.GL10?, c: javax.microedition.khronos.egl.EGLConfig?) {
        GLES20.glClearColor(.05f,.09f,.14f,1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        program = makeProgram(vs,fs)
        pos = GLES20.glGetAttribLocation(program,"aPosition")
        color = GLES20.glGetUniformLocation(program,"uColor")
    }

    override fun onSurfaceChanged(gl: javax.microedition.khronos.opengles.GL10?, w:Int,h:Int) {
        GLES20.glViewport(0,0,w,h)
    }

    override fun onDrawFrame(gl: javax.microedition.khronos.opengles.GL10?) {
        if (!done) {
            val speed = if (running) 0.065f else 0.032f
            px = (px + inputX * speed).coerceIn(-3.1f,3.1f)
            pz = (pz + inputY * speed).coerceIn(-3.1f,3.1f)

            if (jumpRequested && py <= 0.001f) {
                jumpVelocity = 0.12f
                jumpRequested = false
            }
            if (py > 0f || jumpVelocity > 0f) {
                py += jumpVelocity
                jumpVelocity -= 0.008f
                if (py <= 0f) {
                    py = 0f
                    jumpVelocity = 0f
                }
            }

            collectNearbyCubes()
        }

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        draw(quad(0f,0f,2f,2f),floatArrayOf(.16f,.48f,.20f,1f))
        for(c in cubes) {
            draw(quad(c[0]/3.5f,c[1]/3.5f,.09f,.09f),floatArrayOf(1f,.72f,.05f,1f))
        }
        draw(
            quad(px/3.5f,pz/3.5f - py/3.5f,.13f,.13f),
            floatArrayOf(.15f,.55f,1f,1f)
        )
    }

    fun setMoveInput(x: Float, y: Float, sprint: Boolean) {
        inputX = x.coerceIn(-1f,1f)
        inputY = y.coerceIn(-1f,1f)
        running = sprint
    }

    fun setRunning(value: Boolean) {
        running = value
    }

    fun jump() {
        if (!done) jumpRequested = true
    }

    private fun collectNearbyCubes() {
        val it = cubes.iterator()
        while(it.hasNext()){
            val c=it.next()
            if(abs(c[0]-px)<.48f && abs(c[1]-pz)<.48f){
                it.remove()
                score++
                onScore(score)
                if(score>=10){
                    done=true
                    onFinished()
                }
            }
        }
    }

    private fun quad(x:Float,y:Float,w:Float,h:Float)=floatArrayOf(
        x-w,y-h,0f,x+w,y-h,0f,x+w,y+h,0f,
        x-w,y-h,0f,x+w,y+h,0f,x-w,y+h,0f
    )

    private fun draw(v:FloatArray,c:FloatArray){
        val b=java.nio.ByteBuffer.allocateDirect(v.size*4)
            .order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer()
        b.put(v).position(0)
        GLES20.glUseProgram(program)
        GLES20.glEnableVertexAttribArray(pos)
        GLES20.glVertexAttribPointer(pos,3,GLES20.GL_FLOAT,false,0,b)
        GLES20.glUniform4fv(color,1,c,0)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,v.size/3)
        GLES20.glDisableVertexAttribArray(pos)
    }

    private fun shader(t:Int,src:String):Int{
        val id=GLES20.glCreateShader(t)
        GLES20.glShaderSource(id,src)
        GLES20.glCompileShader(id)
        return id
    }

    private fun makeProgram(v:String,f:String):Int{
        val p=GLES20.glCreateProgram()
        GLES20.glAttachShader(p,shader(GLES20.GL_VERTEX_SHADER,v))
        GLES20.glAttachShader(p,shader(GLES20.GL_FRAGMENT_SHADER,f))
        GLES20.glLinkProgram(p)
        return p
    }
}
