# XOLBOR — Android prototype

XOLBOR is a Roblox-inspired **original game hub prototype**: games live inside the XOLBOR app instead of being downloaded as separate APKs.

Included in this starter:
- Animated XOLBOR splash screen
- Email/username + password login UI
- Google login UI placeholder (real OAuth needs your Google/Firebase project)
- Boy and girl default avatars
- Avatar customization + coin prices
- XOLBOR coins
- 4 original 3D game modes using OpenGL ES
- Private servers with "members can join without invite" setting
- YouTube creator reward flow (500 coins after verification)
- Owner-only moderation screen
- Ban / unban by username
- Promote / demote administrators
- Owner protection: owner cannot be banned
- Four game cards:
  1. Cube Lift 3D
  2. Phoenix Pet Ride 3D
  3. Neon Drives 3D
  4. Sky Rails 3D

## Important before publishing

This is a prototype. For a real multiplayer platform you need a backend for:
- Accounts, password hashing, sessions and account recovery
- Google authentication / OAuth
- Coins and purchases
- Avatar inventory
- Private-server membership
- Ban/admin roles
- Creator verification and the 10,000-subscriber rule
- Anti-cheat and moderation logs

Do NOT put a real owner password or admin secret in the APK. Owner/admin permissions must be enforced on a trusted server.

For Galaxy Store, build a release APK/AAB, sign it, test it on Samsung devices, and register it in Samsung Seller Portal. Samsung currently requires target API level >= 33 and at least one 64-bit binary. See the official Samsung documentation before submission.

## Jogos jogáveis no APK
A versão atual inclui quatro mini-jogos locais jogáveis dentro do aplicativo, com loop de jogo, pontuação, vidas e controles por toque:
- Cube Lift 3D: toque para pular e desvie do cubo.
- Phoenix Pet Ride 3D: mova o pet e pegue cristais.
- Neon Drives 3D: toque nos lados para trocar de faixa e desviar.
- Sky Rails 3D: toque no lado do trilho para trocar de linha.

Esses são mini-jogos de protótipo com visual pseudo-3D/arcade. Para uma versão comercial maior, ainda será necessário adicionar modelos 3D completos, áudio, física avançada, contas online, multiplayer e backend.

### Personalização de skins
A interface inclui skins prontas e um criador de skin com nome, corpo, cabelo e acessórios. Para sincronizar skins entre dispositivos e moderar conteúdo criado pelos jogadores, será necessário um backend seguro.

### Evolução 3D
Foi adicionada uma prévia 3D nativa do avatar, com corpo, cabeça, cabelo e acessórios baseados nas escolhas do criador de skins. A visualização pode ser girada por toque. Esta é uma base leve; para produção, os jogos e o avatar devem usar um motor 3D completo e assets otimizados.

### Fluxo da página inicial
Depois do cadastro/login, o usuário deve chegar à home do XOLBOR, onde aparecem os recomendados, jogos, perfil, amigos, avatar, moedas e servidores. O jogo só é aberto quando o usuário escolhe um título.

### Nova identidade visual
A versão desta entrega usa a nova logo original do XOLBOR (símbolo X neon com coroa, anel orbital e lettering XOLBOR) no ícone do aplicativo, splash screen, tela de login/cadastro e cabeçalho da home.

## Chat nos jogos
- Cada jogo agora tem um botão de chat no topo.
- Jogadores podem enviar mensagens durante a partida.
- O protótipo inclui filtro básico de linguagem e opção de silenciar jogadores.
- Para a versão online, o chat deve usar backend, moderação no servidor, denúncias, bloqueio/mute persistente e controles de segurança adequados.
