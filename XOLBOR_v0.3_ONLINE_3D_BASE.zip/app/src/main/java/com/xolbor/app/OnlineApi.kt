package com.xolbor.app

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Small REST client for the XOLBOR backend.
 * Set BuildConfig.XOLBOR_API_URL to your deployed HTTPS API.
 */
object OnlineApi {
    private var token: String? = null
    private var currentUser: JSONObject? = null
    private var prefs: android.content.SharedPreferences? = null

    fun init(context: Context) {
        if (prefs != null) return
        prefs = context.applicationContext.getSharedPreferences("xolbor_session", Context.MODE_PRIVATE)
        token = prefs?.getString("token", null)
        currentUser = prefs?.getString("user", null)?.let { runCatching { JSONObject(it) }.getOrNull() }
    }

    suspend fun restoreSession(): Boolean = withContext(Dispatchers.IO) {
        if (token.isNullOrBlank()) return@withContext false
        try { me(); true } catch (_: Exception) { logout(); false }
    }

    private fun saveSession() {
        prefs?.edit()?.putString("token", token)?.putString("user", currentUser?.toString())?.apply()
    }

    private fun request(method: String, path: String, body: JSONObject? = null): JSONObject = run {
        val base = BuildConfig.XOLBOR_API_URL.trimEnd('/')
        val conn = (URL(base + path).openConnection() as HttpURLConnection)
        conn.requestMethod = method
        conn.connectTimeout = 10000
        conn.readTimeout = 15000
        conn.setRequestProperty("Accept", "application/json")
        token?.let { conn.setRequestProperty("Authorization", "Bearer $it") }
        if (body != null) {
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
        val obj = if (text.isBlank()) JSONObject() else JSONObject(text)
        if (code !in 200..299) throw IllegalStateException(obj.optString("error", "Erro HTTP $code"))
        obj
    }

    suspend fun signup(email: String, username: String, password: String): JSONObject = withContext(Dispatchers.IO) {
        val res = request("POST", "/auth/signup", JSONObject().apply {
            put("email", email); put("username", username); put("password", password)
        })
        token = res.getString("token"); currentUser = res.getJSONObject("user"); saveSession(); res
    }

    suspend fun login(identifier: String, password: String): JSONObject = withContext(Dispatchers.IO) {
        val res = request("POST", "/auth/login", JSONObject().apply {
            put("identifier", identifier); put("password", password)
        })
        token = res.getString("token"); currentUser = res.getJSONObject("user"); saveSession(); res
    }

    suspend fun me(): JSONObject = withContext(Dispatchers.IO) { request("GET", "/me").also { currentUser = it.getJSONObject("user"); saveSession() } }

    suspend fun games(): JSONArray = withContext(Dispatchers.IO) { request("GET", "/games").getJSONArray("games") }

    suspend fun createGame(name: String, description: String, icon: String): JSONObject = withContext(Dispatchers.IO) {
        request("POST", "/games", JSONObject().apply {
            put("name", name); put("description", description); put("icon", icon)
        })
    }

    suspend fun sendChat(gameId: String, text: String): JSONObject = withContext(Dispatchers.IO) {
        request("POST", "/games/$gameId/chat", JSONObject().put("text", text))
    }

    suspend fun chat(gameId: String, after: Long = 0): JSONArray = withContext(Dispatchers.IO) {
        request("GET", "/games/$gameId/chat?after=$after").getJSONArray("messages")
    }

    suspend fun spendCoins(amount: Int, reason: String): JSONObject = withContext(Dispatchers.IO) {
        request("POST", "/wallet/spend", JSONObject().put("amount", amount).put("reason", reason))
    }

    suspend fun ban(username: String, reason: String = "Moderação"): JSONObject = withContext(Dispatchers.IO) {
        request("POST", "/admin/ban", JSONObject().apply { put("username", username); put("reason", reason) })
    }
    suspend fun unban(username: String): JSONObject = withContext(Dispatchers.IO) {
        request("POST", "/admin/unban", JSONObject().put("username", username))
    }
    suspend fun setRole(username: String, role: String): JSONObject = withContext(Dispatchers.IO) {
        request("POST", "/admin/role", JSONObject().apply { put("username", username); put("role", role) })
    }
    suspend fun adminUsers(): JSONArray = withContext(Dispatchers.IO) { request("GET", "/admin/users").getJSONArray("users") }
    suspend fun friends(): JSONObject = withContext(Dispatchers.IO) { request("GET", "/friends") }
    suspend fun friendRequests(): JSONObject = withContext(Dispatchers.IO) { request("GET", "/friends/requests") }
    suspend fun searchUsers(query: String): JSONArray = withContext(Dispatchers.IO) { request("GET", "/users/search?q=${java.net.URLEncoder.encode(query, "UTF-8")}").getJSONArray("users") }
    suspend fun sendFriendRequest(username: String): JSONObject = withContext(Dispatchers.IO) { request("POST", "/friends/request", JSONObject().put("username", username)) }
    suspend fun acceptFriendRequest(username: String): JSONObject = withContext(Dispatchers.IO) { request("POST", "/friends/accept", JSONObject().put("username", username)) }

    fun isLoggedIn() = token != null
    fun user() = currentUser
    fun logout() { token = null; currentUser = null; prefs?.edit()?.clear()?.apply() }
}
