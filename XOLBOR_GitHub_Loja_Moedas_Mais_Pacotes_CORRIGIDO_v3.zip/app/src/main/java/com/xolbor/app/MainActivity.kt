package com.xolbor.app
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import kotlin.math.cos
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.FilterChip

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import org.json.JSONArray
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import android.view.View
import android.view.MotionEvent
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.Typeface
import android.content.Context
import kotlin.math.sin
import kotlin.math.abs

private val XBlue = Color(0xFF1683FF)
private val XDark = Color(0xFF07111F)
private val XCard = Color(0xFF111C2C)

data class Game(val id: Int, val title: String, val subtitle: String, val rating: Int, val icon: String, val creator: String = "XOLBOR", val serverId: String? = null)

data class CoinPackage(
    val sku: String,
    val coins: Int,
    val title: String,
    val description: String
)

val coinPackages = listOf(
    CoinPackage("xolbor_coins_100", 100, "100 moedas", "Pacote inicial"),
    CoinPackage("xolbor_coins_500", 500, "500 moedas", "Pacote popular"),
    CoinPackage("xolbor_coins_1200", 1200, "1.200 moedas", "Pacote grande"),
    CoinPackage("xolbor_coins_3000", 3000, "3.000 moedas", "Pacote máximo"),
    CoinPackage("xolbor_coins_5000", 5000, "5.000 moedas", "Pacote avançado"),
    CoinPackage("xolbor_coins_10000", 10000, "10.000 moedas", "Pacote premium"),
    CoinPackage("xolbor_coins_25000", 25000, "25.000 moedas", "Pacote especial"),
    CoinPackage("xolbor_coins_50000", 50000, "50.000 moedas", "Pacote gigante"),
    CoinPackage("xolbor_coins_100000", 100000, "100.000 moedas", "Pacote lendário")
)

data class Skin(val name: String, val price: Int, val emoji: String)
data class Friend(val name: String, val status: String, val avatar: String)
data class ChatMessage(val user: String, val text: String, val mine: Boolean = false)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { XolborApp() }
    }
}

@Composable
fun XolborApp() {
    var splash by remember { mutableStateOf(true) }
    var loggedIn by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var coins by remember { mutableIntStateOf(1250) }
    var selectedGame by remember { mutableStateOf<Game?>(null) }
    var games by remember { mutableStateOf(initialGames()) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = XBlue,
            background = XDark,
            surface = XCard
        )
    ) {
        if (splash) {
            SplashScreen(onDone = { splash = false })
        } else if (!loggedIn) {
            LoginScreen(onLoggedIn = { loggedIn = true })
        } else if (selectedGame != null) {
            GameScreen(game = selectedGame!!, onBack = { selectedGame = null })
        } else {
            MainShell(
                tab = tab,
                onTab = { tab = it },
                coins = coins,
                onCoins = { coins = it },
                games = games,
                onGames = { games = it },
                onGame = { selectedGame = it }
            )
        }
    }
}

@Composable
fun SplashScreen(onDone: () -> Unit) {
    val scale = remember { Animatable(0.5f) }
    LaunchedEffect(Unit) {
        scale.animateTo(1f, tween(700))
        kotlinx.coroutines.delay(900)
        onDone()
    }
    Box(
        Modifier.fillMaxSize().background(XDark),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                painter = painterResource(id = com.xolbor.app.R.drawable.xolbor_logo),
                contentDescription = "Logo XOLBOR",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(260.dp)
                    .graphicsLayer(scaleX = scale.value, scaleY = scale.value)
            )
            Text("Jogue. Crie. Personalize.", color = Color.LightGray, fontSize = 16.sp)
        }
    }
}

@Composable
fun LoginScreen(onLoggedIn: () -> Unit) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf("login") }
    var method by remember { mutableStateOf("email") }
    var step by remember { mutableIntStateOf(1) }
    var email by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var confirmPass by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    fun finishSignup() {
        error = when {
            !email.contains("@") -> "Digite um e-mail válido."
            username.length < 3 -> "O nome de usuário precisa ter pelo menos 3 caracteres."
            pass.length < 8 -> "A senha precisa ter pelo menos 8 caracteres."
            pass != confirmPass -> "As senhas não são iguais."
            else -> ""
        }
        if (error.isEmpty()) {
            busy = true
            scope.launch {
                try { OnlineApi.signup(email, username, pass); onLoggedIn() }
                catch (e: Exception) { error = e.message ?: "Não foi possível criar a conta." }
                finally { busy = false }
            }
        }
    }

    Box(Modifier.fillMaxSize().background(XDark), contentAlignment = Alignment.Center) {
        Card(
            colors = CardDefaults.cardColors(containerColor = XCard),
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier.padding(22.dp).fillMaxWidth()
        ) {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Image(
                    painter = painterResource(id = com.xolbor.app.R.drawable.xolbor_logo),
                    contentDescription = "Logo XOLBOR",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.size(150.dp).align(Alignment.CenterHorizontally)
                )
                Text(
                    if (mode == "login") "Entrar" else "Criar conta",
                    fontSize = 25.sp,
                    fontWeight = FontWeight.Bold
                )

                if (mode == "login") {
                    OutlinedTextField(
                        email, { email = it; error = "" },
                        label = { Text("Usuário ou e-mail") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        pass, { pass = it; error = "" },
                        label = { Text("Senha") },
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            if (email.isBlank() || pass.isBlank()) { error = "Preencha usuário/e-mail e senha." }
                            else {
                                busy = true; error = ""
                                scope.launch {
                                    try { OnlineApi.login(email, pass); onLoggedIn() }
                                    catch (e: Exception) { error = e.message ?: "Falha ao entrar." }
                                    finally { busy = false }
                                }
                            }
                        },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (busy) "ENTRANDO…" else "ENTRAR") }

                    OutlinedButton(onClick = { error = "Login Google ainda precisa ser ligado ao Google Identity/Firebase. O login por e-mail já usa o backend XOLBOR." }, modifier = Modifier.fillMaxWidth()) {
                        Text("Continuar com Google")
                    }
                    Text(
                        "Não tem conta? Criar conta",
                        color = XBlue,
                        modifier = Modifier.clickable {
                            mode = "signup"
                            method = "email"
                            step = 1
                            error = ""
                        }
                    )
                } else {
                    if (step == 1) {
                        Text("1. Escolha como criar sua conta", color = Color.LightGray, fontSize = 14.sp)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = method == "email",
                                onClick = { method = "email"; error = "" },
                                label = { Text("📧 E-mail") },
                                modifier = Modifier.weight(1f)
                            )
                            FilterChip(
                                selected = method == "google",
                                onClick = { method = "google"; error = "" },
                                label = { Text("G Google") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (method == "email") {
                            OutlinedTextField(
                                email, { email = it; error = "" },
                                label = { Text("Seu e-mail") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Button(
                                onClick = {
                                    if (email.contains("@") && email.contains(".")) { step = 2; error = "" }
                                    else error = "Digite um e-mail válido."
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("CONTINUAR") }
                        } else {
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF17263D))) {
                                Column(Modifier.padding(14.dp)) {
                                    Text("Conta Google", fontWeight = FontWeight.Bold)
                                    Text("Na versão final, este botão abrirá o login seguro do Google. O XOLBOR não recebe sua senha do Google.", color = Color.LightGray, fontSize = 12.sp)
                                }
                            }
                            Button(
                                onClick = { step = 2; error = "" },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("CONTINUAR COM GOOGLE") }
                        }
                    } else {
                        Text("2. Crie seu perfil XOLBOR", color = Color.LightGray, fontSize = 14.sp)
                        if (method == "google") {
                            Text("Google conectado (protótipo)", color = XBlue, fontSize = 13.sp)
                        }
                        OutlinedTextField(
                            username, { username = it; error = "" },
                            label = { Text("Nome de usuário") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            pass, { pass = it; error = "" },
                            label = { Text("Senha XOLBOR") },
                            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            confirmPass, { confirmPass = it; error = "" },
                            label = { Text("Confirmar senha") },
                            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Button(onClick = { finishSignup() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                            Text(if (busy) "CRIANDO…" else "CRIAR CONTA")
                        }
                        Text(
                            "← Voltar",
                            color = XBlue,
                            modifier = Modifier.clickable { step = 1; error = "" }
                        )
                    }

                    Text(
                        "Já tenho uma conta",
                        color = XBlue,
                        modifier = Modifier.clickable { mode = "login"; step = 1; error = "" }
                    )
                }

                if (error.isNotBlank()) Text(error, color = Color(0xFFFF8A80), fontSize = 13.sp)
                Text(
                    "Online: contas por e-mail já usam o backend XOLBOR com senha protegida por hash e sessão JWT. O Google será conectado na próxima etapa.",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }
        }
    }
}

fun initialGames(): List<Game> = listOf(
    Game(1, "Cube Lift 3D", "Levante o cubo gigante", 94, "🧊", "XOLBOR", "1"),
    Game(2, "Phoenix Pet Ride 3D", "Monte um pet lendário", 96, "🔥", "XOLBOR", "2"),
    Game(3, "Neon Drives 3D", "Construa e pilote", 97, "🏎️", "XOLBOR", "3"),
    Game(4, "Sky Rails 3D", "Corra pelos trilhos", 95, "🎢", "XOLBOR", "4"),
    Game(5, "Treasure Island 3D", "Encontre tesouros escondidos", 93, "🏝️", "XOLBOR", "5"),
    Game(6, "Zombie Escape 3D", "Escape antes do tempo acabar", 91, "🧟", "XOLBOR", "6"),
    Game(7, "Space Builders 3D", "Construa sua base espacial", 96, "🚀", "XOLBOR", "7"),
    Game(8, "Volcano Run 3D", "Corra da lava", 92, "🌋", "XOLBOR", "8"),
    Game(9, "Pet World 3D", "Cuide e evolua seus pets", 95, "🐾", "XOLBOR", "9"),
    Game(10, "Battle Arena 3D", "Desafie outros jogadores", 94, "⚔️", "XOLBOR", "10")
)

@Composable
fun MainShell(
    tab: Int,
    onTab: (Int) -> Unit,
    coins: Int,
    onCoins: (Int) -> Unit,
    games: List<Game>,
    onGames: (List<Game>) -> Unit,
    onGame: (Game) -> Unit
) {

    Scaffold(
        containerColor = XDark,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF061A35)) {
                listOf("Início", "Jogos", "Avatar", "Amigos", "Servidores", "Loja", "Perfil").forEachIndexed { i, label ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { onTab(i) },
                        icon = {
                            Icon(
                                when(i) {
                                    0 -> Icons.Default.Home
                                    1 -> Icons.Default.SportsEsports
                                    2 -> Icons.Default.Person
                                    3 -> Icons.Default.Group
                                    4 -> Icons.Default.Cloud
                                    5 -> Icons.Default.ShoppingCart
                                    else -> Icons.Default.AccountCircle
                                }, contentDescription = label
                            )
                        },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            Row(
                Modifier.fillMaxWidth().padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    painter = painterResource(id = com.xolbor.app.R.drawable.xolbor_logo),
                    contentDescription = "Logo XOLBOR",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.size(58.dp)
                )
                Surface(shape = RoundedCornerShape(20.dp), color = Color(0xFF17263D)) {
                    Text("🪙 $coins", modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp), fontWeight = FontWeight.Bold)
                }
            }

            when (tab) {
                0 -> HomeTab(games, onGame)
                1 -> GamesTab(games, onGame, onGames)
                2 -> AvatarTab(coins, onCoins)
                3 -> FriendsTab()
                4 -> ServersTab()
                5 -> StoreTab(coins)
                6 -> ProfileTab(coins)
            }
        }
    }
}

@Composable
fun HomeTab(games: List<Game>, onGame: (Game) -> Unit) {
    val friends = listOf(
        Friend("NandoX", "Online", "🧑"),
        Friend("LuhGames", "Jogando Neon Drives", "👩"),
        Friend("RafaBR", "Online", "🧑"),
        Friend("PixelLeo", "Offline", "🧑")
    )
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Recomendados", fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(games.take(3)) { game ->
                    Card(
                        modifier = Modifier.width(230.dp).clickable { onGame(game) },
                        colors = CardDefaults.cardColors(containerColor = XCard),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Box(Modifier.fillMaxWidth().height(100.dp).background(Color(0xFF173B65), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                                Text(game.icon, fontSize = 48.sp)
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(game.title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text(game.subtitle, color = Color.LightGray, maxLines = 1)
                        }
                    }
                }
            }
        }
        item {
            Text("Seus amigos", fontSize = 21.sp, fontWeight = FontWeight.Bold)
            androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(friends.take(4)) { friend ->
                    Card(colors = CardDefaults.cardColors(containerColor = XCard), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.width(115.dp).padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(friend.avatar, fontSize = 34.sp)
                            Text(friend.name, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text(friend.status, fontSize = 11.sp, color = if (friend.status == "Offline") Color.Gray else Color(0xFF70E58A), maxLines = 1)
                        }
                    }
                }
            }
        }
        item { Text("Todos os jogos", fontSize = 21.sp, fontWeight = FontWeight.Bold) }
        items(games) { game -> GameCard(game, onGame) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0E2A45))) {
                Column(Modifier.padding(18.dp)) {
                    Text("🎥 Programa de YouTubers", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Text("Criadores com até 10.000 inscritos podem solicitar verificação. Após confirmação e vídeo sobre um jogo XOLBOR, a recompensa é de 500 moedas.")
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = {}) { Text("Solicitar verificação") }
                }
            }
        }
    }
}

@Composable
fun GamesTab(games: List<Game>, onGame: (Game) -> Unit, onGames: (List<Game>) -> Unit) {
    val scope = rememberCoroutineScope()
    var creating by remember { mutableStateOf(false) }
    if (creating) {
        CreateGameScreen(
            onCancel = { creating = false },
            onCreate = { title, description, icon ->
                creating = false
                scope.launch {
                    try {
                        val obj = OnlineApi.createGame(title, description, icon).getJSONObject("game")
                        val id = obj.optString("id").hashCode()
                        onGames(games + Game(id, title, description, 100, icon, obj.optString("owner_username", "Você")))
                    } catch (_: Exception) {
                        val nextId = (games.maxOfOrNull { it.id } ?: 0) + 1
                        onGames(games + Game(nextId, title, description, 100, icon, "Você (offline)"))
                    }
                }
            }
        )
        return
    }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Todos os jogos", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("${games.size} jogos disponíveis", color = Color.LightGray)
                }
                Button(onClick = { creating = true }) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("Criar jogo")
                }
            }
        }
        items(games) { GameCard(it, onGame) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF102B45))) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("🎮 Crie seu próprio jogo", fontWeight = FontWeight.Bold, fontSize = 19.sp)
                    Text("Escolha nome, descrição e ícone. No modo online, seus jogos poderão ser publicados para outros jogadores.", color = Color.LightGray)
                    Text("Protótipo: a publicação e os mundos 3D reais precisam de servidor/backend.", color = Color.Gray, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun CreateGameScreen(onCancel: () -> Unit, onCreate: (String, String, String) -> Unit) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var icon by remember { mutableStateOf("🎮") }
    var error by remember { mutableStateOf("") }
    val icons = listOf("🎮", "🏝️", "🚀", "⚔️", "🏎️", "🐾", "🌋", "🧟", "🏰", "⭐")
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onCancel) { Icon(Icons.Default.ArrowBack, contentDescription = "Voltar") }
            Text("Criar jogo", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        }
        Card(colors = CardDefaults.cardColors(containerColor = XCard), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Novo jogo", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(title, { title = it.take(30); error = "" }, label = { Text("Nome do jogo") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(description, { description = it.take(80); error = "" }, label = { Text("Descrição") }, modifier = Modifier.fillMaxWidth())
                Text("Escolha o ícone", color = Color.LightGray)
                androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(icons) { item ->
                        FilterChip(selected = icon == item, onClick = { icon = item }, label = { Text(item, fontSize = 22.sp) })
                    }
                }
                Button(onClick = {
                    when {
                        title.trim().length < 3 -> error = "O nome precisa ter pelo menos 3 caracteres."
                        description.trim().length < 5 -> error = "Escreva uma descrição curta."
                        else -> onCreate(title.trim(), description.trim(), icon)
                    }
                }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Publish, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("CRIAR E PUBLICAR")
                }
                if (error.isNotBlank()) Text(error, color = Color(0xFFFF8A80), fontSize = 13.sp)
            }
        }
        Text("Na versão online, haverá editor de mapas, objetos, scripts seguros, testes e publicação/moderação.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun GameCard(game: Game, onGame: (Game) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onGame(game) },
        colors = CardDefaults.cardColors(containerColor = XCard),
        shape = RoundedCornerShape(22.dp)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(82.dp).background(Color(0xFF153A66), RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center
            ) { Text(game.icon, fontSize = 42.sp) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(game.title, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text(game.subtitle, color = Color.LightGray)
                Text("👍 Avaliação ${game.rating}%", color = Color.LightGray)
                Text("Criado por ${game.creator}", color = Color.Gray, fontSize = 12.sp)
            }
            Icon(Icons.Default.PlayArrow, contentDescription = "Jogar", tint = XBlue)
        }
    }
}

@Composable
fun AvatarTab(coins: Int, onCoins: (Int) -> Unit) {
    var gender by remember { mutableStateOf("menino") }
    val skins = listOf(
        Skin("Padrão menino", 0, "🧑"),
        Skin("Padrão menina", 0, "👩"),
        Skin("Neon", 350, "🕶️"),
        Skin("Galaxy", 600, "🌌"),
        Skin("Fogo", 800, "🔥")
    )
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Personalizar", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = gender == "menino", onClick = { gender = "menino" }, label = { Text("Menino 🧑") })
            FilterChip(selected = gender == "menina", onClick = { gender = "menina" }, label = { Text("Menina 👩") })
        }
        Spacer(Modifier.height(14.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(skins) { skin ->
                Card(colors = CardDefaults.cardColors(containerColor = XCard)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(skin.emoji, fontSize = 35.sp)
                        Spacer(Modifier.width(12.dp))
                        Text(skin.name, Modifier.weight(1f), fontWeight = FontWeight.Bold)
                        if (skin.price == 0) Text("Grátis")
                        else Button(onClick = { if (coins >= skin.price) onCoins(coins - skin.price) }) {
                            Text("🪙 ${skin.price}")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FriendsTab() {
    val friends = listOf(
        Friend("NandoX", "Online", "🧑"), Friend("LuhGames", "Jogando Neon Drives", "👩"),
        Friend("RafaBR", "Online", "🧑"), Friend("PixelLeo", "Offline", "🧑"),
        Friend("BiaPlay", "Online", "👩")
    )
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Amizades", fontSize = 25.sp, fontWeight = FontWeight.Bold) }
        items(friends) { friend ->
            Card(colors = CardDefaults.cardColors(containerColor = XCard), shape = RoundedCornerShape(18.dp)) {
                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(friend.avatar, fontSize = 34.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { Text(friend.name, fontWeight = FontWeight.Bold); Text(friend.status, color = Color.LightGray, fontSize = 13.sp) }
                    OutlinedButton(onClick = {}) { Text("Ver perfil") }
                }
            }
        }
    }
}

@Composable
fun StoreTab(coins: Int) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Loja de moedas", fontSize = 28.sp, fontWeight = FontWeight.Black)
            Text(
                "Escolha um pacote de moedas XOLBOR. O preço final será definido no sistema de cobrança da loja.",
                color = Color.LightGray,
                fontSize = 14.sp
            )
            Spacer(Modifier.height(8.dp))
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = Color(0xFF17263D),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("Saldo atual", color = Color.LightGray)
                    Text("🪙 $coins moedas", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        items(coinPackages) { pack ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101F36)),
                shape = RoundedCornerShape(20.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("🪙 ${pack.coins}", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text(pack.title, fontWeight = FontWeight.SemiBold)
                        Text(pack.description, color = Color.LightGray, fontSize = 13.sp)
                        Text("ID: ${pack.sku}", color = Color.Gray, fontSize = 11.sp)
                    }
                    OutlinedButton(onClick = {
                        // O botão fica pronto para ser ligado ao Google Play Billing / Galaxy Store IAP.
                    }) {
                        Text("Comprar")
                    }
                }
            }
        }
        item {
            Text(
                "Pagamento: esta tela não guarda dados bancários. A integração de cobrança deve usar o sistema oficial da loja e credenciais configuradas no console do desenvolvedor.",
                color = Color.Gray,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
fun ProfileTab(coins: Int) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Meu perfil", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = XCard), shape = RoundedCornerShape(24.dp)) {
            Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(88.dp).background(Color(0xFF173B65), RoundedCornerShape(44.dp)), contentAlignment = Alignment.Center) { Text("🧑", fontSize = 48.sp) }
                Spacer(Modifier.width(16.dp))
                Column { Text("XOLBOR", fontSize = 23.sp, fontWeight = FontWeight.Black); Text("@xolbor", color = Color.LightGray); Text("🪙 $coins moedas", color = XBlue) }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = XCard)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Estatísticas", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("🎮 Jogos jogados: 24")
                Text("🏆 Vitórias: 11")
                Text("👥 Amigos: 5")
                Text("🎨 Skins desbloqueadas: 3")
            }
        }
        Text("Perfil e inventário reais serão sincronizados pelo servidor na versão online.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun ServersTab() {
    var openJoin by remember { mutableStateOf(true) }
    Column(Modifier.padding(16.dp)) {
        Text("Servidores privados", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Card(colors = CardDefaults.cardColors(containerColor = XCard)) {
            Column(Modifier.padding(16.dp)) {
                Text("Sala XOLBOR #001", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("12/30 jogadores")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Membros entram sem convite", Modifier.weight(1f))
                    Switch(checked = openJoin, onCheckedChange = { openJoin = it })
                }
                Button(onClick = {}) { Text("ENTRAR") }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Os servidores privados devem ser controlados pelo backend para impedir que a configuração seja burlada.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun AdminTab() {
    var target by remember { mutableStateOf("") }
    var isAdmin by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Painel do dono", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Conta proprietária: XOLBOR", color = XBlue)
        OutlinedTextField(target, { target = it }, label = { Text("Nome do usuário") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { if (target.isNotBlank() && target.uppercase() != "XOLBOR") message = "$target foi banido." }) { Text("Banir") }
            OutlinedButton(onClick = { if (target.isNotBlank()) message = "$target foi desbanido." }) { Text("Desbanir") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { if (target.isNotBlank() && target.uppercase() != "XOLBOR") { isAdmin = true; message = "$target agora é administrador." } }) { Text("Promover") }
            OutlinedButton(onClick = { if (target.isNotBlank()) { isAdmin = false; message = "$target foi rebaixado." } }) { Text("Rebaixar") }
        }
        if (message.isNotBlank()) Text(message, color = Color(0xFF7CFF9A))
        Text("Proteção: a conta XOLBOR não pode ser banida. Em produção, essas regras precisam ser verificadas no servidor.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun GameScreen(game: Game, onBack: () -> Unit) {
    var showFriends by remember { mutableStateOf(false) }
    var showChat by remember { mutableStateOf(false) }
    val friends = listOf(
        Friend("NandoX", "Online", "🧑"),
        Friend("LuhGames", "Jogando Neon Drives", "👩"),
        Friend("RafaBR", "Online", "🧑"),
        Friend("PixelLeo", "Offline", "🧑")
    )
    val messages = remember {
        mutableStateListOf(
            ChatMessage("NandoX", "Bora jogar!"),
            ChatMessage("LuhGames", "Esse mapa ficou legal 😄")
        )
    }
    var gameView by remember { mutableStateOf<XolborGameView?>(null) }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Voltar", tint = Color.White)
                }
                Column(Modifier.weight(1f)) {
                    Text(game.title, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text("Jogo 3D local • controles por toque", color = Color.LightGray, fontSize = 12.sp)
                }
                IconButton(onClick = { showChat = !showChat; showFriends = false }) {
                    Icon(Icons.Default.Chat, contentDescription = "Chat", tint = Color.White)
                }
                IconButton(onClick = { showFriends = !showFriends; showChat = false }) {
                    Icon(Icons.Default.Group, contentDescription = "Amigos", tint = Color.White)
                }
            }
            Box(Modifier.weight(1f)) {
                PlayableGameView(game.id, Modifier.fillMaxSize(), onReady = { gameView = it })
                MobileGameControls(gameView)
            }
        }

        if (showChat) {
            GameChatPanel(
                gameId = game.serverId ?: game.id.toString(),
                messages = messages,
                onClose = { showChat = false }
            )
        }

        if (showFriends) {
            Card(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 66.dp, end = 10.dp)
                    .widthIn(min = 250.dp, max = 330.dp),
                colors = CardDefaults.cardColors(containerColor = XCard),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("👥 Amigos", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text("${friends.count { it.status != "Offline" }} online", color = Color(0xFF70E58A), fontSize = 12.sp)
                    }
                    friends.forEach { friend ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(friend.avatar, fontSize = 27.sp)
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(friend.name, fontWeight = FontWeight.Bold)
                                Text(friend.status, color = Color.LightGray, fontSize = 11.sp, maxLines = 1)
                            }
                            if (friend.status != "Offline") Text("●", color = Color(0xFF70E58A)) else Text("○", color = Color.Gray)
                        }
                    }
                    OutlinedButton(onClick = { showFriends = false }, modifier = Modifier.fillMaxWidth()) {
                        Text("Fechar")
                    }
                }
            }
        }
    }
}

@Composable
fun GameChatPanel(
    gameId: String,
    messages: MutableList<ChatMessage>,
    onClose: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var draft by remember { mutableStateOf("") }
    var muted by remember { mutableStateOf(setOf<String>()) }
    var notice by remember { mutableStateOf("") }
    var lastMessageId by remember { mutableLongStateOf(0L) }

    LaunchedEffect(gameId) {
        while (true) {
            try {
                val arr = OnlineApi.chat(gameId, lastMessageId)
                for (i in 0 until arr.length()) {
                    val item = arr.getJSONObject(i)
                    val id = item.optLong("id")
                    if (id > lastMessageId) lastMessageId = id
                    val name = item.optString("username", "Jogador")
                    if (name != (OnlineApi.user()?.optString("username") ?: "")) messages.add(ChatMessage(name, item.optString("text"), false))
                }
            } catch (_: Exception) { }
            kotlinx.coroutines.delay(2500)
        }
    }

    val blockedWords = listOf(
        "idiota", "burro", "otario", "otário", "palhaco", "palhaço", "merda", "porra",
        "caralho", "viado", "fdp", "filho da puta"
    )

    fun filterMessage(text: String): String {
        var result = text.trim()
        blockedWords.forEach { word ->
            val regex = Regex("(?i)" + Regex.escape(word))
            result = regex.replace(result, "***")
        }
        return result
    }

    fun sendMessage() {
        val clean = filterMessage(draft)
        if (clean.isBlank()) return
        draft = ""
        scope.launch {
            try {
                OnlineApi.sendChat(gameId, clean)
                messages.add(ChatMessage(OnlineApi.user()?.optString("username", "Você") ?: "Você", clean, true))
                notice = "Mensagem enviada para o servidor"
            } catch (e: Exception) {
                messages.add(ChatMessage("Você", clean, true))
                notice = "Modo offline: ${e.message ?: "servidor indisponível"}"
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        Card(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 62.dp, end = 10.dp)
            .widthIn(min = 280.dp, max = 360.dp)
            .heightIn(min = 360.dp, max = 520.dp),
        colors = CardDefaults.cardColors(containerColor = XCard),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("💬 Chat do jogo", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Fale com quem está na sala", color = Color.LightGray, fontSize = 11.sp)
                }
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Fechar chat")
                }
            }

            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                items(messages.filter { it.user !in muted }) { msg ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.mine) Arrangement.End else Arrangement.Start) {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (msg.mine) Color(0xFF164E82) else Color(0xFF18263A)
                            ),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Column(Modifier.padding(horizontal = 10.dp, vertical = 7.dp)) {
                                Text(msg.user, fontSize = 11.sp, color = Color.LightGray, fontWeight = FontWeight.Bold)
                                Text(msg.text, fontSize = 14.sp)
                                if (!msg.mine) {
                                    TextButton(
                                        onClick = {
                                            muted = muted + msg.user
                                            notice = "${msg.user} foi silenciado nesta sala."
                                        },
                                        contentPadding = PaddingValues(0.dp)
                                    ) { Text("Silenciar", fontSize = 10.sp) }
                                }
                            }
                        }
                    }
                }
            }

            if (notice.isNotBlank()) {
                Text(notice, color = Color(0xFF8FD3FF), fontSize = 11.sp, modifier = Modifier.padding(bottom = 4.dp))
            }

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
                OutlinedTextField(
                    value = draft,
                    onValueChange = { draft = it.take(120) },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Digite uma mensagem…") },
                    maxLines = 3
                )
                Spacer(Modifier.width(6.dp))
                IconButton(onClick = { sendMessage() }) {
                    Icon(Icons.Default.Send, contentDescription = "Enviar")
                }
            }
            Text(
                "Filtro automático • denunciar e moderar no servidor na versão online",
                color = Color.Gray,
                fontSize = 10.sp,
                modifier = Modifier.padding(top = 5.dp)
            )
        }
        }
    }
}

@Composable
fun PlayableGameView(mode: Int, modifier: Modifier = Modifier, onReady: (XolborGameView) -> Unit = {}) {
    val context = LocalContext.current
    AndroidView(
        factory = { XolborGameView(context, mode).also(onReady) },
        modifier = modifier
    )
}

@Composable
fun MobileGameControls(gameView: XolborGameView?) {
    var running by remember { mutableStateOf(false) }
    var joyX by remember { mutableFloatStateOf(0f) }
    var joyY by remember { mutableFloatStateOf(0f) }

    Box(Modifier.fillMaxSize().padding(16.dp)) {
        Box(
            Modifier.align(Alignment.BottomStart)
                .size(150.dp)
                .background(Color(0x663A4A60), RoundedCornerShape(75.dp))
                .pointerInput(gameView) {
                    detectDragGestures(
                        onDragEnd = { joyX = 0f; joyY = 0f; gameView?.setMoveInput(0f, 0f, running) },
                        onDragCancel = { joyX = 0f; joyY = 0f; gameView?.setMoveInput(0f, 0f, running) },
                        onDrag = { change, drag ->
                            change.consume()
                            joyX = (joyX + drag.x / 75f).coerceIn(-1f, 1f)
                            joyY = (joyY + drag.y / 75f).coerceIn(-1f, 1f)
                            gameView?.setMoveInput(joyX, joyY, running)
                        }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.size(58.dp).offset((joyX * 38f).dp, (joyY * 38f).dp)
                .background(Color(0xDD1683FF), RoundedCornerShape(29.dp)))
            Text("ANDAR", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }

        Row(Modifier.align(Alignment.BottomEnd).padding(bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = { running = !running; gameView?.setRunning(running); gameView?.setMoveInput(joyX, joyY, running) },
                colors = ButtonDefaults.buttonColors(containerColor = if (running) Color(0xFF19A55B) else Color(0xCC26384D))
            ) { Text(if (running) "🏃 Correndo" else "🏃 Correr") }
            Button(
                onClick = { gameView?.jump() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xCC7A42D6))
            ) { Text("🦘 Pular") }
        }
    }
}

/**
 * Mini-games jogáveis que rodam diretamente dentro do APK.
 * São leves e não dependem de servidor para funcionar no protótipo.
 */
class XolborGameView(context: Context, private val mode: Int) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD }
    private var playerX = 0.5f
    private var playerY = 0.78f
    private var velocityY = 0f
    private var score = 0
    private var lives = 3
    private var gameOver = false
    private var lastTime = System.nanoTime()
    private var elapsed = 0f
    private var spawnTimer = 0f
    private var obstacleX = 0.65f
    private var obstacleY = 0.15f
    private var obstacleLane = 1
    private var targetLane = 1
    private var collected = 0
    private var touchDownX = 0f
    private var touchDownY = 0f
    private var inputX = 0f
    private var inputY = 0f
    private var running = false
    private val speed: Float get() = if (running) 0.75f else 0.38f
    private var jumpRequested = false
    private var jumpTimer = 0f

    init {
        isFocusable = true
        setBackgroundColor(AndroidColor.BLACK)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = System.nanoTime()
        var dt = (now - lastTime) / 1_000_000_000f
        lastTime = now
        dt = dt.coerceIn(0f, 0.05f)
        if (!gameOver) update(dt)
        drawScene(canvas)
        if (!gameOver) postInvalidateDelayed(16) else invalidate()
    }

    private fun update(dt: Float) {
        elapsed += dt
        if (jumpTimer > 0f) jumpTimer -= dt
        if (jumpRequested) { jumpTimer = 0.55f }
        when (mode) {
            1 -> updateCubeLift(dt)
            2 -> updatePhoenix(dt)
            3 -> updateNeonDrive(dt)
            else -> updateSkyRails(dt)
        }
    }

    private fun updateCubeLift(dt: Float) {
        playerX = (playerX + inputX * speed * dt).coerceIn(0.12f, 0.88f)
        if (jumpRequested && playerY >= 0.75f) { velocityY = -1.05f; jumpRequested = false }
        velocityY += 1.8f * dt
        playerY += velocityY * dt
        if (playerY > 0.78f) {
            playerY = 0.78f
            velocityY = 0f
        }
        obstacleY += 0.42f * dt
        if (obstacleY > 0.9f) {
            obstacleY = 0.08f
            obstacleX = 0.25f + Math.random().toFloat() * 0.5f
            score += 10
        }
        if (abs(playerX - obstacleX) < 0.10f && abs(playerY - obstacleY) < 0.10f) {
            lives--
            obstacleY = 0.08f
            obstacleX = 0.25f + Math.random().toFloat() * 0.5f
            if (lives <= 0) gameOver = true
        }
    }

    private fun updatePhoenix(dt: Float) {
        playerX = (playerX + inputX * speed * dt).coerceIn(0.08f, 0.92f)
        spawnTimer += dt
        obstacleY += 0.30f * dt
        if (obstacleY > 0.9f) {
            obstacleY = 0.08f
            obstacleX = 0.12f + Math.random().toFloat() * 0.76f
        }
        if (abs(playerX - obstacleX) < 0.09f && abs(playerY - obstacleY) < 0.09f) {
            collected++
            score += 25
            obstacleY = 0.08f
            obstacleX = 0.12f + Math.random().toFloat() * 0.76f
        }
        playerY = 0.55f + sin(elapsed * 2.2f) * 0.16f - if (jumpTimer > 0f) 0.16f else 0f
    }

    private fun updateNeonDrive(dt: Float) {
        if (abs(inputX) > 0.35f) targetLane = (targetLane + if (inputX > 0) 1 else -1).coerceIn(0, 2)
        playerX += (targetLane * 0.5f + 0.5f - playerX) * minOf(1f, dt * 8f)
        obstacleY += 0.55f * dt
        if (obstacleY > 1.05f) {
            obstacleY = 0.08f
            obstacleLane = (0..2).random()
            score += 15
        }
        val obstaclePos = 0.25f + obstacleLane * 0.25f
        if (obstacleY > 0.72f && obstacleY < 0.88f && abs(playerX - obstaclePos) < 0.09f) {
            lives--
            obstacleY = 0.08f
            obstacleLane = (0..2).random()
            if (lives <= 0) gameOver = true
        }
    }

    private fun updateSkyRails(dt: Float) {
        if (abs(inputX) > 0.35f) targetLane = if (inputX < 0) 0 else 1
        playerX += (targetLane * 0.5f + 0.25f - playerX) * minOf(1f, dt * 7f)
        obstacleY += 0.38f * dt
        if (obstacleY > 1.0f) {
            obstacleY = 0.05f
            obstacleLane = (0..1).random()
            score += 12
        }
        val obstaclePos = if (obstacleLane == 0) 0.33f else 0.67f
        if (obstacleY > 0.68f && obstacleY < 0.86f && abs(playerX - obstaclePos) < 0.12f) {
            lives--
            obstacleY = 0.05f
            if (lives <= 0) gameOver = true
        }
    }

    private fun drawScene(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        paint.style = Paint.Style.FILL
        paint.color = AndroidColor.rgb(5, 12, 25)
        canvas.drawRect(0f, 0f, w, h, paint)

        when (mode) {
            1 -> drawCubeLift(canvas, w, h)
            2 -> drawPhoenix(canvas, w, h)
            3 -> drawNeonDrive(canvas, w, h)
            else -> drawSkyRails(canvas, w, h)
        }

        textPaint.color = AndroidColor.WHITE
        textPaint.textSize = 18f
        canvas.drawText("Pontos: $score", 18f, 30f, textPaint)
        canvas.drawText("❤ $lives", w - 90f, 30f, textPaint)

        if (gameOver) {
            paint.color = AndroidColor.argb(220, 0, 0, 0)
            canvas.drawRect(0f, 0f, w, h, paint)
            textPaint.textSize = 34f
            textPaint.color = AndroidColor.WHITE
            textPaint.textAlign = Paint.Align.CENTER
            canvas.drawText("FIM DE JOGO", w / 2f, h / 2f - 20f, textPaint)
            textPaint.textSize = 18f
            canvas.drawText("Toque para jogar novamente", w / 2f, h / 2f + 25f, textPaint)
            textPaint.textAlign = Paint.Align.LEFT
        }
    }

    private fun drawCubeLift(canvas: Canvas, w: Float, h: Float) {
        drawGrid(canvas, w, h)
        drawCube(canvas, playerX * w, playerY * h, 46f, AndroidColor.CYAN)
        drawCube(canvas, obstacleX * w, obstacleY * h, 42f, AndroidColor.MAGENTA)
        drawButton(canvas, w, h, "TOQUE / PULE")
    }

    private fun drawPhoenix(canvas: Canvas, w: Float, h: Float) {
        drawStars(canvas, w, h)
        val x = playerX * w
        val y = playerY * h
        paint.color = AndroidColor.rgb(255, 90, 20)
        canvas.drawCircle(x, y, 32f, paint)
        paint.color = AndroidColor.YELLOW
        canvas.drawCircle(x + 20f, y - 8f, 14f, paint)
        paint.color = AndroidColor.RED
        canvas.drawOval(x - 55f, y - 5f, x - 5f, y + 24f, paint)
        canvas.drawOval(x + 5f, y - 5f, x + 55f, y + 24f, paint)
        paint.color = AndroidColor.CYAN
        canvas.drawCircle(obstacleX * w, obstacleY * h, 14f, paint)
        textPaint.color = AndroidColor.WHITE
        textPaint.textSize = 16f
        canvas.drawText("Cristais: $collected", 18f, h - 70f, textPaint)
        drawButton(canvas, w, h, "MOVA PARA PEGAR")
    }

    private fun drawNeonDrive(canvas: Canvas, w: Float, h: Float) {
        paint.color = AndroidColor.rgb(20, 20, 35)
        canvas.drawRect(0f, 0f, w, h, paint)
        for (i in 0..12) {
            val y = h * 0.35f + i * h * 0.055f
            paint.color = AndroidColor.rgb(30, 80, 120)
            canvas.drawLine(w * 0.18f, y, w * 0.82f, y, paint)
        }
        for (lane in 0..2) {
            val x = w * (0.25f + lane * 0.25f)
            paint.color = AndroidColor.rgb(70, 40, 120)
            canvas.drawLine(x, h * 0.25f, x, h * 0.9f, paint)
        }
        drawCar(canvas, playerX * w, h * 0.82f, 50f, AndroidColor.CYAN)
        drawCar(canvas, (0.25f + obstacleLane * 0.25f) * w, obstacleY * h, 44f, AndroidColor.MAGENTA)
        textPaint.color = AndroidColor.LTGRAY
        textPaint.textSize = 16f
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("←  Toque à esquerda/direita  →", w / 2f, h - 28f, textPaint)
        textPaint.textAlign = Paint.Align.LEFT
    }

    private fun drawSkyRails(canvas: Canvas, w: Float, h: Float) {
        drawStars(canvas, w, h)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 8f
        paint.color = AndroidColor.CYAN
        canvas.drawLine(w * 0.33f, h * 0.2f, w * 0.33f, h, paint)
        paint.color = AndroidColor.MAGENTA
        canvas.drawLine(w * 0.67f, h * 0.2f, w * 0.67f, h, paint)
        paint.style = Paint.Style.FILL
        drawCube(canvas, playerX * w, h * 0.78f, 48f, AndroidColor.WHITE)
        val ox = if (obstacleLane == 0) 0.33f else 0.67f
        drawCube(canvas, ox * w, obstacleY * h, 40f, AndroidColor.YELLOW)
        textPaint.color = AndroidColor.WHITE
        textPaint.textSize = 16f
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("Toque no lado do trilho para trocar", w / 2f, h - 28f, textPaint)
        textPaint.textAlign = Paint.Align.LEFT
    }

    private fun drawGrid(canvas: Canvas, w: Float, h: Float) {
        paint.color = AndroidColor.rgb(15, 40, 65)
        for (i in 0..10) canvas.drawLine(0f, h * i / 10f, w, h * i / 10f, paint)
        for (i in 0..10) canvas.drawLine(w * i / 10f, 0f, w * i / 10f, h, paint)
    }

    private fun drawStars(canvas: Canvas, w: Float, h: Float) {
        paint.color = AndroidColor.WHITE
        for (i in 0..30) {
            val x = ((i * 73) % 100) / 100f * w
            val y = ((i * 47) % 85) / 100f * h
            canvas.drawCircle(x, y, if (i % 3 == 0) 3f else 1.5f, paint)
        }
    }

    private fun drawCube(canvas: Canvas, cx: Float, cy: Float, size: Float, color: Int) {
        paint.color = color
        paint.style = Paint.Style.FILL
        canvas.drawRect(cx - size / 2, cy - size / 2, cx + size / 2, cy + size / 2, paint)
        paint.color = AndroidColor.argb(120, 255, 255, 255)
        canvas.drawRect(cx - size / 2, cy - size / 2, cx, cy, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        paint.color = AndroidColor.WHITE
        canvas.drawRect(cx - size / 2, cy - size / 2, cx + size / 2, cy + size / 2, paint)
        paint.style = Paint.Style.FILL
    }

    private fun drawCar(canvas: Canvas, cx: Float, cy: Float, size: Float, color: Int) {
        paint.color = color
        canvas.drawRoundRect(cx - size / 2, cy - size / 2, cx + size / 2, cy + size / 2, 12f, 12f, paint)
        paint.color = AndroidColor.DKGRAY
        canvas.drawRect(cx - size * .28f, cy - size * .30f, cx + size * .28f, cy, paint)
    }

    private fun drawButton(canvas: Canvas, w: Float, h: Float, label: String) {
        paint.color = AndroidColor.argb(150, 20, 40, 70)
        canvas.drawRoundRect(18f, h - 58f, w - 18f, h - 10f, 18f, 18f, paint)
        textPaint.color = AndroidColor.WHITE
        textPaint.textSize = 15f
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(label, w / 2f, h - 29f, textPaint)
        textPaint.textAlign = Paint.Align.LEFT
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touchDownX = event.x
                touchDownY = event.y
                if (gameOver) resetGame()
                return true
            }
            MotionEvent.ACTION_UP -> {
                val dx = event.x - touchDownX
                val w = width.toFloat()
                when (mode) {
                    1 -> if (abs(dx) > 35f) playerX = (playerX + if (dx > 0) 0.10f else -0.10f).coerceIn(0.12f, 0.88f) else if (playerY >= 0.75f) velocityY = -1.05f
                    2 -> playerX = (event.x / w).coerceIn(0.08f, 0.92f)
                    3 -> targetLane = if (event.x < w / 2f) maxOf(0, targetLane - 1) else minOf(2, targetLane + 1)
                    else -> targetLane = if (event.x < w / 2f) 0 else 1
                }
                invalidate()
                return true
            }
        }
        return true
    }

    fun setMoveInput(x: Float, y: Float, sprint: Boolean) {
        inputX = x.coerceIn(-1f, 1f)
        inputY = y.coerceIn(-1f, 1f)
        running = sprint
    }

    fun setRunning(value: Boolean) { running = value }

    fun jump() { if (!gameOver) jumpRequested = true }

    private fun resetGame() {
        playerX = 0.5f
        playerY = 0.78f
        velocityY = 0f
        score = 0
        lives = 3
        gameOver = false
        elapsed = 0f
        obstacleY = 0.08f
        obstacleX = 0.65f
        obstacleLane = 1
        targetLane = 1
        collected = 0
        lastTime = System.nanoTime()
        postInvalidateDelayed(16)
    }
}

/* XOLBOR_SKIN_CREATOR */
@Composable
fun XolborSkinCreator(
    coins: Int,
    onCoinsChange: (Int) -> Unit
) {
    var skinName by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("Azul") }
    var hair by remember { mutableStateOf("Clássico") }
    var accessory by remember { mutableStateOf("Nenhum") }
    var created by remember { mutableStateOf(false) }

    val skins = listOf(
        "Neon", "Galaxy", "Fire", "Ice", "Shadow", "Cyber", "Lava",
        "Ocean", "Forest", "Sunset", "Royal", "Crystal", "Robot", "Ninja"
    )

    Column(
        modifier = Modifier.fillMaxWidth().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("🎨 Criador de Skin", style = MaterialTheme.typography.titleLarge)
        Text(
            "Crie seu próprio visual e use a skin no seu avatar.",
            style = MaterialTheme.typography.bodyMedium
        )

        OutlinedTextField(
            value = skinName,
            onValueChange = { skinName = it.take(20) },
            label = { Text("Nome da skin") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Text("Skins prontas", style = MaterialTheme.typography.titleMedium)
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.heightIn(max = 280.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(skins) { name ->
                Button(onClick = {
                    skinName = name
                    created = true
                }) {
                    Text(name)
                }
            }
        }

        Text("Cor do corpo")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Azul", "Vermelho", "Verde", "Roxo", "Amarelo").forEach {
                FilterChip(
                    selected = body == it,
                    onClick = { body = it },
                    label = { Text(it) }
                )
            }
        }

        Text("Cabelo")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Clássico", "Moicano", "Cacheado", "Cyber").forEach {
                FilterChip(
                    selected = hair == it,
                    onClick = { hair = it },
                    label = { Text(it) }
                )
            }
        }

        Text("Acessório")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Nenhum", "Óculos", "Boné", "Coroa", "Fone").forEach {
                FilterChip(
                    selected = accessory == it,
                    onClick = { accessory = it },
                    label = { Text(it) }
                )
            }
        }

        Button(
            onClick = {
                if (skinName.isNotBlank()) created = true
            },
            enabled = skinName.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Salvar e usar minha skin")
        }

        if (created) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("✅ Skin equipada", style = MaterialTheme.typography.titleMedium)
                    Text("$skinName • $body • $hair • $accessory")
                }
            }
        }
    }
}

/* XOLBOR_3D_AVATAR_EVOLUTION */

/**
 * Preview 3D simples do avatar XOLBOR.
 * O mesmo visual (bodyColor/hair/accessory) é usado para montar a renderização.
 * A câmera pode ser girada por toque.
 */
@Composable
fun XolborAvatar3DPreview(
    bodyColor: String,
    hair: String,
    accessory: String,
    modifier: Modifier = Modifier
) {
    AndroidView(
        modifier = modifier
            .fillMaxWidth()
            .height(300.dp),
        factory = { context ->
            val avatarRenderer = XolborAvatarRenderer(bodyColor, hair, accessory)
            val view = GLSurfaceView(context).apply {
                setEGLContextClientVersion(2)
                setRenderer(avatarRenderer)
                renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
            }
            var downX = 0f
            view.setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.x
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.x - downX
                        (v as GLSurfaceView).queueEvent {
                            avatarRenderer.rotateBy(dx * 0.5f)
                        }
                        downX = e.x
                        true
                    }
                    else -> true
                }
            }
            view
        }
    )
}

class XolborAvatarRenderer(
    private val bodyColorName: String,
    private val hairName: String,
    private val accessoryName: String
) : GLSurfaceView.Renderer {

    private var angle = 0f
    private var program = 0
    private var positionHandle = 0
    private var colorHandle = 0

    private val vertexShader = """
        attribute vec4 aPosition;
        uniform mat4 uMvp;
        void main() { gl_Position = uMvp * aPosition; }
    """.trimIndent()

    private val fragmentShader = """
        precision mediump float;
        uniform vec4 uColor;
        void main() { gl_FragColor = uColor; }
    """.trimIndent()

    override fun onSurfaceCreated(gl: javax.microedition.khronos.opengles.GL10?, config: javax.microedition.khronos.egl.EGLConfig?) {
        GLES20.glClearColor(0.08f, 0.09f, 0.12f, 1f)
        program = buildProgram(vertexShader, fragmentShader)
        positionHandle = GLES20.glGetAttribLocation(program, "aPosition")
        colorHandle = GLES20.glGetUniformLocation(program, "uColor")
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
    }

    override fun onSurfaceChanged(gl: javax.microedition.khronos.opengles.GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(gl: javax.microedition.khronos.opengles.GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        // A full 3D engine can replace this renderer later; this renderer provides
        // a lightweight Android-native 3D avatar preview without external assets.
        drawCube(0f, 0f, 0f, 0.72f, 0.95f, color(bodyColorName))
        drawCube(0f, 1.05f, 0f, 0.48f, 0.48f, floatArrayOf(0.95f, 0.72f, 0.50f, 1f))
        drawCube(-0.62f, 0.02f, 0f, 0.22f, 0.75f, color(bodyColorName))
        drawCube(0.62f, 0.02f, 0f, 0.22f, 0.75f, color(bodyColorName))
        drawCube(-0.22f, -0.95f, 0f, 0.23f, 0.75f, floatArrayOf(0.12f,0.12f,0.14f,1f))
        drawCube(0.22f, -0.95f, 0f, 0.23f, 0.75f, floatArrayOf(0.12f,0.12f,0.14f,1f))
        if (hairName != "Clássico") {
            drawCube(0f, 1.42f, 0f, 0.52f, 0.16f, floatArrayOf(0.12f,0.06f,0.03f,1f))
        }
        if (accessoryName != "Nenhum") {
            drawCube(0f, 1.58f, 0f, 0.55f, 0.08f, floatArrayOf(0.95f,0.75f,0.15f,1f))
        }
        angle += 0.35f
    }

    fun rotateBy(delta: Float) { angle += delta }

    private fun drawCube(x: Float, y: Float, z: Float, sx: Float, sy: Float, c: FloatArray) {
        val verts = floatArrayOf(
            -1f,-1f,-1f, 1f,-1f,-1f, 1f,1f,-1f, -1f,1f,-1f,
            -1f,-1f,1f, 1f,-1f,1f, 1f,1f,1f, -1f,1f,1f
        )
        val idx = shortArrayOf(
            0,1,2, 2,3,0, 4,5,6, 6,7,4,
            0,4,7, 7,3,0, 1,5,6, 6,2,1,
            3,2,6, 6,7,3, 0,1,5, 5,4,0
        )
        val fb = java.nio.ByteBuffer.allocateDirect(verts.size*4).order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer()
        fb.put(verts).position(0)
        val ib = java.nio.ByteBuffer.allocateDirect(idx.size*2).order(java.nio.ByteOrder.nativeOrder()).asShortBuffer()
        ib.put(idx).position(0)

        GLES20.glUseProgram(program)
        GLES20.glEnableVertexAttribArray(positionHandle)
        GLES20.glVertexAttribPointer(positionHandle,3,GLES20.GL_FLOAT,false,0,fb)
        GLES20.glUniform4fv(colorHandle,1,c,0)
        GLES20.glDrawElements(GLES20.GL_TRIANGLES,idx.size,GLES20.GL_UNSIGNED_SHORT,ib)
        GLES20.glDisableVertexAttribArray(positionHandle)
    }

    private fun color(n: String) = when(n) {
        "Vermelho" -> floatArrayOf(0.85f,0.15f,0.15f,1f)
        "Verde" -> floatArrayOf(0.15f,0.75f,0.25f,1f)
        "Roxo" -> floatArrayOf(0.55f,0.25f,0.85f,1f)
        "Amarelo" -> floatArrayOf(0.95f,0.75f,0.12f,1f)
        else -> floatArrayOf(0.18f,0.45f,0.85f,1f)
    }

    private fun buildProgram(v: String, f: String): Int {
        fun shader(type: Int, src: String): Int {
            val id = GLES20.glCreateShader(type)
            GLES20.glShaderSource(id, src)
            GLES20.glCompileShader(id)
            return id
        }
        val vs = shader(GLES20.GL_VERTEX_SHADER, v)
        val fs = shader(GLES20.GL_FRAGMENT_SHADER, f)
        val id = GLES20.glCreateProgram()
        GLES20.glAttachShader(id, vs); GLES20.glAttachShader(id, fs)
        GLES20.glLinkProgram(id)
        return id
    }
}

/* XOLBOR_CUBE_LIFT_COMPLETE */
@Composable
fun CubeLift3DGame(onExit: () -> Unit) {
    var score by remember { mutableStateOf(0) }
    var finished by remember { mutableStateOf(false) }
    var rendererRef by remember { mutableStateOf<CubeLiftRenderer?>(null) }
    var running by remember { mutableStateOf(false) }
    var joystickX by remember { mutableFloatStateOf(0f) }
    var joystickY by remember { mutableFloatStateOf(0f) }

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                GLSurfaceView(context).apply {
                    setEGLContextClientVersion(2)
                    val renderer = CubeLiftRenderer(
                        onScore = { score = it },
                        onFinished = { finished = true }
                    )
                    rendererRef = renderer
                    setRenderer(renderer)
                    renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
                    setOnTouchListener { _, _ -> true }
                }
            }
        )

        Box(
            Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("CUBE LIFT 3D", color = Color.White, fontSize = 20.sp)
                Text("🧱 $score / 10", color = Color.White, fontSize = 20.sp)
            }

            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .size(150.dp)
                    .background(Color(0x553A4A60), RoundedCornerShape(75.dp))
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragEnd = {
                                joystickX = 0f
                                joystickY = 0f
                                rendererRef?.setMoveInput(0f, 0f, running)
                            },
                            onDragCancel = {
                                joystickX = 0f
                                joystickY = 0f
                                rendererRef?.setMoveInput(0f, 0f, running)
                            },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                joystickX = (joystickX + dragAmount.x / 75f).coerceIn(-1f, 1f)
                                joystickY = (joystickY + dragAmount.y / 75f).coerceIn(-1f, 1f)
                                rendererRef?.setMoveInput(joystickX, joystickY, running)
                            }
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                Box(
                    Modifier
                        .size(58.dp)
                        .offset(
                            x = (joystickX * 38f).dp,
                            y = (joystickY * 38f).dp
                        )
                        .background(Color(0xCC1683FF), RoundedCornerShape(29.dp))
                )
                Text("MOVE", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Row(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        running = !running
                        rendererRef?.setRunning(running)
                        rendererRef?.setMoveInput(joystickX, joystickY, running)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (running) Color(0xFF19A55B) else Color(0xCC26384D)
                    )
                ) {
                    Text(if (running) "🏃 Correndo" else "🏃 Correr")
                }

                Button(
                    onClick = { rendererRef?.jump() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xCC7A42D6))
                ) {
                    Text("🦘 Pular")
                }
            }

            if (finished) {
                Card(
                    Modifier
                        .align(Alignment.Center)
                        .padding(16.dp)
                ) {
                    Column(
                        Modifier.padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("🏆 Você completou o Cube Lift 3D!")
                        Text("Pontuação: $score")
                        Button(onClick = onExit) { Text("Voltar para XOLBOR") }
                    }
                }
            }

            Button(
                onClick = onExit,
                modifier = Modifier.align(Alignment.BottomCenter)
            ) {
                Text("Sair do jogo")
            }
        }
    }
}

class CubeLiftRenderer(
    val onScore: (Int) -> Unit,
    val onFinished: () -> Unit
) : GLSurfaceView.Renderer {
    private var program = 0
    private var pos = 0
    private var color = 0
    @Volatile private var px = 0f
    @Volatile private var pz = 0f
    @Volatile private var py = 0f
    @Volatile private var inputX = 0f
    @Volatile private var inputY = 0f
    @Volatile private var running = false
    @Volatile private var jumpRequested = false
    private var jumpVelocity = 0f
    private var score = 0
    private var done = false

    private val cubes = mutableListOf(
        floatArrayOf(-2.2f,-1.5f), floatArrayOf(1.8f,-1.1f),
        floatArrayOf(-1.1f,.8f), floatArrayOf(2.1f,1.4f),
        floatArrayOf(0f,2f), floatArrayOf(-2.3f,2f),
        floatArrayOf(2.5f,0f), floatArrayOf(-.4f,-2.3f),
        floatArrayOf(1f,2.6f), floatArrayOf(-2.7f,-.1f)
    )
    private val vs = "attribute vec4 aPosition; void main(){gl_Position=aPosition;}"
    private val fs = "precision mediump float; uniform vec4 uColor; void main(){gl_FragColor=uColor;}"

    override fun onSurfaceCreated(gl: javax.microedition.khronos.opengles.GL10?, c: javax.microedition.khronos.egl.EGLConfig?) {
        GLES20.glClearColor(.05f,.09f,.14f,1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        program = makeProgram(vs,fs)
        pos = GLES20.glGetAttribLocation(program,"aPosition")
        color = GLES20.glGetUniformLocation(program,"uColor")
    }

    override fun onSurfaceChanged(gl: javax.microedition.khronos.opengles.GL10?, w:Int,h:Int) {
        GLES20.glViewport(0,0,w,h)
    }

    override fun onDrawFrame(gl: javax.microedition.khronos.opengles.GL10?) {
        if (!done) {
            val speed = if (running) 0.065f else 0.032f
            px = (px + inputX * speed).coerceIn(-3.1f,3.1f)
            pz = (pz + inputY * speed).coerceIn(-3.1f,3.1f)

            if (jumpRequested && py <= 0.001f) {
                jumpVelocity = 0.12f
                jumpRequested = false
            }
            if (py > 0f || jumpVelocity > 0f) {
                py += jumpVelocity
                jumpVelocity -= 0.008f
                if (py <= 0f) {
                    py = 0f
                    jumpVelocity = 0f
                }
            }

            collectNearbyCubes()
        }

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        draw(quad(0f,0f,2f,2f),floatArrayOf(.16f,.48f,.20f,1f))
        for(c in cubes) {
            draw(quad(c[0]/3.5f,c[1]/3.5f,.09f,.09f),floatArrayOf(1f,.72f,.05f,1f))
        }
        draw(
            quad(px/3.5f,pz/3.5f - py/3.5f,.13f,.13f),
            floatArrayOf(.15f,.55f,1f,1f)
        )
    }

    fun setMoveInput(x: Float, y: Float, sprint: Boolean) {
        inputX = x.coerceIn(-1f,1f)
        inputY = y.coerceIn(-1f,1f)
        running = sprint
    }

    fun setRunning(value: Boolean) {
        running = value
    }

    fun jump() {
        if (!done) jumpRequested = true
    }

    private fun collectNearbyCubes() {
        val it = cubes.iterator()
        while(it.hasNext()){
            val c=it.next()
            if(abs(c[0]-px)<.48f && abs(c[1]-pz)<.48f){
                it.remove()
                score++
                onScore(score)
                if(score>=10){
                    done=true
                    onFinished()
                }
            }
        }
    }

    private fun quad(x:Float,y:Float,w:Float,h:Float)=floatArrayOf(
        x-w,y-h,0f,x+w,y-h,0f,x+w,y+h,0f,
        x-w,y-h,0f,x+w,y+h,0f,x-w,y+h,0f
    )

    private fun draw(v:FloatArray,c:FloatArray){
        val b=java.nio.ByteBuffer.allocateDirect(v.size*4)
            .order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer()
        b.put(v).position(0)
        GLES20.glUseProgram(program)
        GLES20.glEnableVertexAttribArray(pos)
        GLES20.glVertexAttribPointer(pos,3,GLES20.GL_FLOAT,false,0,b)
        GLES20.glUniform4fv(color,1,c,0)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,v.size/3)
        GLES20.glDisableVertexAttribArray(pos)
    }

    private fun shader(t:Int,src:String):Int{
        val id=GLES20.glCreateShader(t)
        GLES20.glShaderSource(id,src)
        GLES20.glCompileShader(id)
        return id
    }

    private fun makeProgram(v:String,f:String):Int{
        val p=GLES20.glCreateProgram()
        GLES20.glAttachShader(p,shader(GLES20.GL_VERTEX_SHADER,v))
        GLES20.glAttachShader(p,shader(GLES20.GL_FRAGMENT_SHADER,f))
        GLES20.glLinkProgram(p)
        return p
    }
}
