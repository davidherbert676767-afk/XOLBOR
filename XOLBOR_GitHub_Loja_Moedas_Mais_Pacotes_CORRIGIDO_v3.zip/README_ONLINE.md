# XOLBOR — etapa ONLINE v0.2

Esta versão começa a tirar o XOLBOR do protótipo local e coloca as partes fundamentais no servidor.

### Já preparado
- Contas por e-mail + senha: cadastro/login via API.
- ID único de conta e JWT.
- Senhas com hash bcrypt no servidor.
- Jogos criados pelo jogador ficam associados ao `owner_id` da conta.
- Catálogo e criação de jogos via API.
- Chat por jogo com filtro básico e atualização periódica.
- Carteira de moedas no servidor e endpoint seguro para gastar moedas.
- Cargos e moderação: OWNER, ADMIN, MODERATOR e PLAYER.
- OWNER protegido contra ban/rebaixamento nas rotas de moderação.
- Dez jogos iniciais sem depender de dados locais.

### Ainda não é um serviço público
O servidor está pronto para ser hospedado, mas ninguém pode acessar a internet até colocarmos o backend em um servidor com uma URL HTTPS. O projeto não possui credenciais de hospedagem, domínio ou banco externo, então essa parte precisa ser configurada antes do lançamento.

### Como testar
Backend:
1. Node.js 20+.
2. `cd backend`
3. `npm install`
4. Copie `.env.example` para `.env` e defina `JWT_SECRET` e `OWNER_SETUP_KEY` fortes.
5. `npm start`.
6. `GET /health` deve retornar `ok: true`.

Android:
- Emulador: a URL está em `BuildConfig.XOLBOR_API_URL` como `http://10.0.2.2:8080`.
- Celular físico: troque por `http://IP_DO_PC:8080` apenas para teste na mesma rede.
- Produção: use obrigatoriamente uma URL HTTPS pública e deixe o tráfego HTTP desativado.

### Dono do XOLBOR
Não existe senha de dono gravada no aplicativo. Crie a conta de OWNER uma vez usando a rota `/auth/create-owner` e o cabeçalho `X-Owner-Setup-Key`. Depois guarde as credenciais fora do código.

### Próximas etapas para o online completo
1. Hospedar API + banco gerenciado.
2. Google Identity/Firebase para login Google.
3. WebSocket para multiplayer/chat em tempo real.
4. Sistema de servidores/salas e presença de jogadores.
5. Editor 3D e publicação/moderação dos mundos.
6. Inventário/loja de moedas com validação no servidor.
7. Anti-cheat, logs, denúncias e limites de requisição.
8. HTTPS, backups, monitoramento e proteção de dados.
