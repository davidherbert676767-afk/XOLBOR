package com.xolbor.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Small REST client for the XOLBOR backend.
 * Set BuildConfig.XOLBOR_API_URL to your deployed HTTPS API.
 */
object OnlineApi {
    private var token: String? = null
    private var currentUser: JSONObject? = null

    private fun request(method: String, path: String, body: JSONObject? = null): JSONObject = run {
        val base = BuildConfig.XOLBOR_API_URL.trimEnd('/')
        val conn = (URL(base + path).openConnection() as HttpURLConnection)
        conn.requestMethod = method
        conn.connectTimeout = 10000
        conn.readTimeout = 15000
        conn.setRequestProperty("Accept", "application/json")
        token?.let { conn.setRequestProperty("Authorization", "Bearer $it") }
        if (body != null) {
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
        val obj = if (text.isBlank()) JSONObject() else JSONObject(text)
        if (code !in 200..299) throw IllegalStateException(obj.optString("error", "Erro HTTP $code"))
        obj
    }

    suspend fun signup(email: String, username: String, password: String): JSONObject = withContext(Dispatchers.IO) {
        val res = request("POST", "/auth/signup", JSONObject().apply {
            put("email", email); put("username", username); put("password", password)
        })
        token = res.getString("token"); currentUser = res.getJSONObject("user"); res
    }

    suspend fun login(identifier: String, password: String): JSONObject = withContext(Dispatchers.IO) {
        val res = request("POST", "/auth/login", JSONObject().apply {
            put("identifier", identifier); put("password", password)
        })
        token = res.getString("token"); currentUser = res.getJSONObject("user"); res
    }

    suspend fun me(): JSONObject = withContext(Dispatchers.IO) { request("GET", "/me").also { currentUser = it.getJSONObject("user") } }

    suspend fun games(): JSONArray = withContext(Dispatchers.IO) { request("GET", "/games").getJSONArray("games") }

    suspend fun createGame(name: String, description: String, icon: String): JSONObject = withContext(Dispatchers.IO) {
        request("POST", "/games", JSONObject().apply {
            put("name", name); put("description", description); put("icon", icon)
        })
    }

    suspend fun sendChat(gameId: String, text: String): JSONObject = withContext(Dispatchers.IO) {
        request("POST", "/games/$gameId/chat", JSONObject().put("text", text))
    }

    suspend fun chat(gameId: String, after: Long = 0): JSONArray = withContext(Dispatchers.IO) {
        request("GET", "/games/$gameId/chat?after=$after").getJSONArray("messages")
    }

    suspend fun spendCoins(amount: Int, reason: String): JSONObject = withContext(Dispatchers.IO) {
        request("POST", "/wallet/spend", JSONObject().put("amount", amount).put("reason", reason))
    }

    fun isLoggedIn() = token != null
    fun user() = currentUser
    fun logout() { token = null; currentUser = null }
}
