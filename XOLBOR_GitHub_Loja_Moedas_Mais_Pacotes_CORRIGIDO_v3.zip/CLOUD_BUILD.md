# Compilação do XOLBOR na nuvem

Este projeto já inclui um workflow do GitHub Actions em `.github/workflows/build-apk.yml`.

## Como gerar o APK pelo celular

1. Crie/abra um repositório no GitHub.
2. Envie o conteúdo desta pasta para o repositório.
3. Abra a aba **Actions** do repositório.
4. Selecione **Build XOLBOR APK**.
5. Toque em **Run workflow**.
6. Quando terminar, abra a execução concluída e baixe o artefato **XOLBOR-debug-apk**.
7. Dentro dele estará `app-debug.apk`.

O workflow configura Java 17, Android SDK 35 e Gradle 8.9 automaticamente.

## Observação

O APK gerado é uma build de teste (debug). Isso é diferente de uma versão assinada para publicação na Play Store/Galaxy Store.

O endereço `XOLBOR_API_URL` no projeto está configurado para `http://10.0.2.2:8080`, que é útil para o emulador Android e não é um endereço público. Para o backend online real, será necessário trocar essa configuração por uma URL HTTPS pública.
